"""Threshold-crossing public fixture, byte-exact against old library and sanitized replay."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

repo=Path('/home/ubuntu/project/vsag-lite-baseline-v01')
out=repo / 'lite/benchmark/results/query-visited-specialized-20261011'
build=repo / 'build-lite-fp16-simd-release'
control=Path('/home/ubuntu/project/vsag-visited-bitmap-control-636519e')
sanitize=Path('/home/ubuntu/project/vsag-opt-sanitize-20261009')
commands=[]
results={}
with tempfile.TemporaryDirectory(prefix='vsag-visited-boundary-',dir='/dev/shm') as directory:
    scratch=Path(directory)
    for variant,path in [('control',control),('candidate',build),('sanitize',sanitize)]:
        binary=scratch / variant
        flags=['-O2'] if variant!='sanitize' else ['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
        argv=['c++',*flags,'-std=c++17','-Iinclude','lite/benchmark/visited_boundary_regression.cpp',
              '-L'+str(path),'-lvsag-lite','-o',str(binary)]
        compiled=subprocess.run(argv,cwd=repo,capture_output=True,text=True)
        (out / ('boundary-'+variant+'-compile.stdout')).write_text(compiled.stdout)
        (out / ('boundary-'+variant+'-compile.stderr')).write_text(compiled.stderr)
        assert compiled.returncode==0,compiled.stderr
        env=dict(os.environ,LD_LIBRARY_PATH=str(path),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
        ledger=scratch / (variant+'.ledger')
        run_argv=['taskset','-c','0',str(binary),str(ledger)]
        result=subprocess.run(run_argv,cwd=repo,env=env,capture_output=True)
        (out / ('boundary-'+variant+'.csv')).write_bytes(result.stdout)
        (out / ('boundary-'+variant+'.stderr')).write_bytes(result.stderr)
        assert result.returncode==0,result.stderr
        assert len(result.stdout.splitlines())==160
        results[variant]=dict(output_sha256=hashlib.sha256(result.stdout).hexdigest(),
            ledger_sha256=hashlib.sha256(ledger.read_bytes()).hexdigest(),ledger_bytes=ledger.stat().st_size)
        commands.append(dict(variant=variant,compile_argv=argv,compile_exit=0,argv=run_argv,exit=0,
            library_sha256=hashlib.sha256((path / 'libvsag-lite.so').read_bytes()).hexdigest()))
    assert results['control']==results['candidate']==results['sanitize']
    (out / 'boundary-audit.json').write_text(json.dumps(dict(status='PASS',commands=commands,results=results,
        scope='synthetic dimension1; 65537/65536/65535/65536/65537 nodes; real changed-value Add/Update/Remove; unfiltered/acceptall/even/rejectall; native SaveLoad; 160 output rows/variant'),indent=2)+'\n')
print('PASS threshold crossing, CRUD/filter/SaveLoad output and snapshot SHA exact; ASan/UBSan replay',flush=True)
