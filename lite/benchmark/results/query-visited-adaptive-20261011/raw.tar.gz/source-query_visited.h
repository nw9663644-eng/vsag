// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <vector>

namespace vsag::lite::detail {

// Query-owned bitmap: same word/mask semantics as native VisitedList::TestAndSet,
// without a persistent pool, epoch tags or additional Full dependencies.
class QueryVisited {
public:
    explicit QueryVisited(uint64_t count) : QueryVisited(count, count >= 65536) {
    }

    QueryVisited(uint64_t count, bool packed)
        : packed_(packed),
          words_(packed ? count / 64 + static_cast<uint64_t>(count % 64 != 0) : 0, 0),
          bytes_(packed ? 0 : count, 0) {
    }

    // Slots are already bounded by the index/topology, as with the old byte array.
    [[nodiscard]] bool
    TestAndSet(uint64_t slot) {
        if (not packed_) {
            if (bytes_[slot] != 0) {
                return true;
            }
            bytes_[slot] = 1;
            return false;
        }
        auto& word = words_[slot / 64];
        const uint64_t mask = uint64_t{1} << (slot % 64);
        if ((word & mask) != 0) {
            return true;
        }
        word |= mask;
        return false;
    }

    // Logical word payload, not allocator overhead or process RSS.
    [[nodiscard]] uint64_t
    PayloadBytes() const {
        return words_.size() * sizeof(uint64_t) + bytes_.size();
    }

private:
    const bool packed_;
    std::vector<uint64_t> words_;
    std::vector<uint8_t> bytes_;
};

}  // namespace vsag::lite::detail
