"""Scoped tidy of changed lines; leave unrelated old diagnostics outside this check."""
import json
from pathlib import Path
import subprocess
repo=Path('/home/ubuntu/project/vsag-lite-baseline-v01')
argv=['clang-tidy-15','-p','build-lite-fp16-simd-release','src/lite/rabitq_backend.cpp',
      'src/lite/rabitq_backend_test.cpp',
      '--header-filter=src/lite/rabitq_graph_state.h',
      '--line-filter='+json.dumps([
          dict(name='rabitq_graph_state.h',lines=[[95,150],[295,420],[520,555]]),
          dict(name='rabitq_backend_test.cpp',lines=[[848,1000]]),
          dict(name='rabitq_backend.cpp',lines=[[1,10000]]),
          dict(name='query_repeat_window_probe.cpp',lines=[[1,10000]])])]
result=subprocess.run(argv,cwd=repo,text=True,capture_output=True)
out=Path('/home/ubuntu/project/vsag-routing-final-scoped-tidy-20261011.log')
out.write_text(json.dumps(argv)+'\n'+result.stdout+result.stderr)
print('scoped tidy exit',result.returncode,flush=True)
if result.returncode==0:
    probe=subprocess.run(['clang-tidy-15','lite/benchmark/query_repeat_window_probe.cpp',
        '--','-std=c++17','-Iinclude'],cwd=repo,text=True,capture_output=True)
    Path('/home/ubuntu/project/vsag-routing-final-probe-tidy-20261011.log').write_text(probe.stdout+probe.stderr)
    print('probe tidy exit',probe.returncode,flush=True)
    raise SystemExit(probe.returncode)
raise SystemExit(result.returncode)
