// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include <sys/resource.h>

#if defined(__GLIBC__)
#include <malloc.h>
#endif

#include <algorithm>
#include <array>
#include <catch2/catch_test_macros.hpp>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <limits>
#include <random>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "lite/backend.h"
#include "lite/fp16_codec.h"
#include "lite/query_heap.h"
#include "lite/query_visited.h"

using vsag::lite::detail::make_brute_force_backend;
using vsag::lite::detail::make_fp16_graph_backend;
using vsag::lite::detail::make_graph_backend;

TEST_CASE("query visited bitmap keeps slots independent across word boundaries", "[lite-graph]") {
    using vsag::lite::detail::QueryVisited;
    for (uint64_t count : {uint64_t{0},
                           uint64_t{1},
                           uint64_t{63},
                           uint64_t{64},
                           uint64_t{65},
                           uint64_t{129},
                           uint64_t{100000}}) {
        QueryVisited<true> visited(count);
        QueryVisited<true> independent(count);
        REQUIRE(visited.PayloadBytes() ==
                (count / 64 + static_cast<uint64_t>(count % 64 != 0)) * 8);
        for (uint64_t slot = count; slot > 0; --slot) {
            REQUIRE_FALSE(visited.TestAndSet(slot - 1));
            REQUIRE(visited.TestAndSet(slot - 1));
        }
        for (uint64_t slot = 0; slot < count; ++slot) {
            REQUIRE(visited.TestAndSet(slot));
            REQUIRE_FALSE(independent.TestAndSet(slot));
        }
    }
}

TEST_CASE("query visited byte specialization retains byte-array semantics", "[lite-graph]") {
    using vsag::lite::detail::QueryVisited;
    for (uint64_t count : {uint64_t{0},
                           uint64_t{1},
                           uint64_t{65},
                           uint64_t{65535},
                           uint64_t{65536},
                           uint64_t{65537}}) {
        QueryVisited<false> visited(count);
        REQUIRE(visited.PayloadBytes() == count);
        for (uint64_t slot = 0; slot < count; ++slot) {
            REQUIRE_FALSE(visited.TestAndSet(slot));
            REQUIRE(visited.TestAndSet(slot));
        }
    }
}

TEST_CASE("bounded query heap root replacement matches priority queue", "[lite-graph]") {
    using Record = std::pair<int64_t, uint64_t>;
    using Compare = std::less<Record>;
    using vsag::lite::detail::QueryHeap;
    std::mt19937 random(1701);
    for (uint64_t limit : {uint64_t{1}, uint64_t{2}, uint64_t{3}, uint64_t{16}, uint64_t{512}}) {
        QueryHeap<Record, Compare> actual;
        std::priority_queue<Record, std::vector<Record>, Compare> expected;
        for (uint64_t id = 0; id < 4096; ++id) {
            const Record value{static_cast<int64_t>(random() % 31), id};
            if (expected.size() < limit) {
                actual.push(value);
                expected.push(value);
            } else if (Compare{}(value, expected.top())) {
                actual.ReplaceTop(value);
                expected.push(value);
                expected.pop();
            }
            REQUIRE(actual.size() == expected.size());
            REQUIRE(actual.top() == expected.top());
            REQUIRE(std::is_heap(actual.GetData().begin(), actual.GetData().end(), Compare{}));
        }
        while (not expected.empty()) {
            REQUIRE(actual.top() == expected.top());
            actual.pop();
            expected.pop();
        }
        REQUIRE(actual.empty());
    }
}

namespace {
void
require_incoming_matches(const vsag::lite::detail::Backend& graph) {
    std::vector<std::vector<uint64_t>> expected(graph.Size());
    for (uint64_t source = 0; source < graph.Size(); ++source) {
        for (uint64_t edge = 0; edge < graph.LinkCountAt(source); ++edge) {
            expected[graph.LinkAt(source, edge)].push_back(source);
        }
    }
    for (uint64_t target = 0; target < graph.Size(); ++target) {
        std::vector<uint64_t> actual;
        actual.reserve(graph.IncomingLinkCountAt(target));
        for (uint64_t edge = 0; edge < graph.IncomingLinkCountAt(target); ++edge) {
            actual.push_back(graph.IncomingLinkAt(target, edge));
        }
        std::sort(expected[target].begin(), expected[target].end());
        std::sort(actual.begin(), actual.end());
        REQUIRE(actual == expected[target]);
    }
}
}  // namespace

TEST_CASE("Lite graph backend validates input and survives CRUD", "[lite-graph]") {
    auto flat = make_brute_force_backend(2);
    REQUIRE(flat);
    const std::array<float, 2> a{0, 0};
    const std::array<float, 2> b{1, 0};
    const std::array<float, 2> c{0, 1};
    REQUIRE((*flat)->Add(1, a.data(), 2));
    REQUIRE((*flat)->Add(2, b.data(), 2));
    REQUIRE((*flat)->Add(3, c.data(), 2));
    REQUIRE_FALSE(make_graph_backend(**flat, 1, 8));
    REQUIRE_FALSE(make_graph_backend(**flat, 8, 2));
    auto graph = make_graph_backend(**flat, 4, 32);
    REQUIRE(graph);
    REQUIRE((*graph)->Size() == 3);
    require_incoming_matches(**graph);
    const std::array<float, 2> nonfinite{std::numeric_limits<float>::quiet_NaN(), 0};
    REQUIRE_FALSE((*graph)->Add(4, nonfinite.data(), 2));
    REQUIRE_FALSE((*graph)->Update(2, nonfinite.data(), 2));
    REQUIRE_FALSE((*graph)->Search(nonfinite.data(), 2, 1));
    REQUIRE_FALSE((*graph)->Search(nullptr, 2, 1));
    REQUIRE((*graph)->Search(a.data(), 2, 0)->empty());
    REQUIRE((*graph)->Search(a.data(), 2, 3)->front().id == 1);
    REQUIRE_FALSE((*graph)->Add(1, a.data(), 2));
    REQUIRE_FALSE((*graph)->Add(4, nullptr, 2));
    REQUIRE_FALSE((*graph)->Add(4, a.data(), 1));
    REQUIRE_FALSE((*graph)->Update(9, a.data(), 2));
    REQUIRE((*graph)->Update(2, a.data(), 2));
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Search(a.data(), 2, 2)->size() == 2);
    REQUIRE((*graph)->Remove(1));
    require_incoming_matches(**graph);
    REQUIRE_FALSE((*graph)->Remove(1));
    REQUIRE((*graph)->Size() == 2);
    for (uint64_t slot = 0; slot < (*graph)->Size(); ++slot) {
        for (uint64_t edge = 0; edge < (*graph)->LinkCountAt(slot); ++edge) {
            REQUIRE((*graph)->LinkAt(slot, edge) != slot);
        }
    }
    const auto result = (*graph)->Search(a.data(), 2, 2);
    REQUIRE(result);
    REQUIRE(result->size() == 2);
    REQUIRE(std::none_of(result->begin(), result->end(), [](const auto& n) { return n.id == 1; }));
    REQUIRE((*graph)->Add(1, b.data(), 2));
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Search(b.data(), 2, 3)->size() == 3);
}

TEST_CASE("Lite graph removal cleans asymmetric restored links", "[lite-graph]") {
    using vsag::lite::detail::restore_graph_backend;
    auto graph = restore_graph_backend(
        2, 2, 8, {10, 11, 12, 13}, {0, 0, 1, 0, 0, 1, 1, 1}, {{1}, {}, {3}, {}});
    REQUIRE(graph);
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Remove(11));
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Size() == 3);
    REQUIRE((*graph)->LinkCountAt(0) == 0);
    REQUIRE((*graph)->LinkCountAt(2) == 1);
    REQUIRE((*graph)->LinkAt(2, 0) == 1);
    for (uint64_t slot = 0; slot < (*graph)->Size(); ++slot) {
        for (uint64_t edge = 0; edge < (*graph)->LinkCountAt(slot); ++edge) {
            REQUIRE((*graph)->LinkAt(slot, edge) < (*graph)->Size());
            REQUIRE((*graph)->LinkAt(slot, edge) != slot);
        }
    }
}

TEST_CASE("Lite FP16 VectorAt uses caller-owned scratch", "[lite-graph]") {
    auto flat = make_brute_force_backend(2);
    REQUIRE(flat);
    const std::array<float, 2> first_vector{0.125F, -0.25F};
    const std::array<float, 2> second_vector{1.5F, 2.0F};
    REQUIRE((*flat)->Add(1, first_vector.data(), 2));
    REQUIRE((*flat)->Add(2, second_vector.data(), 2));
    auto graph = make_fp16_graph_backend(**flat, 4, 32);
    REQUIRE(graph);

    std::vector<float> first_scratch;
    std::vector<float> second_scratch;
    const float* first = (*graph)->VectorAt(0, first_scratch);
    const float* second = (*graph)->VectorAt(1, second_scratch);
    REQUIRE(first == first_scratch.data());
    REQUIRE(second == second_scratch.data());
    REQUIRE(first[0] == first_vector[0]);
    REQUIRE(first[1] == first_vector[1]);
    REQUIRE(second[0] == second_vector[0]);
    REQUIRE(second[1] == second_vector[1]);

    require_incoming_matches(**graph);
    REQUIRE((*graph)->Update(2, first_vector.data(), 2));
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Remove(1));
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Add(3, second_vector.data(), 2));
    require_incoming_matches(**graph);
}

TEST_CASE("Lite graph filter traverses rejected IDs and survives snapshot load", "[lite-graph]") {
    auto created = vsag::lite::Index::Create(2);
    REQUIRE(created);
    auto& index = **created;
    std::array<float, 2> vector{};
    for (int64_t slot = 0; slot < 32; ++slot) {
        vector[0] = static_cast<float>(slot);
        REQUIRE(index.Add(1000 + slot, vector.data(), 2));
    }
    REQUIRE(index.BuildGraph(4, 32));
    const std::array<float, 2> query{15, 0};
    const auto unfiltered = index.Search(query.data(), 2, 8);
    REQUIRE(unfiltered);
    const vsag::lite::IdFilter empty_filter;
    const auto without_filter = index.Search(query.data(), 2, 8, empty_filter);
    REQUIRE(without_filter);
    REQUIRE(without_filter->size() == unfiltered->size());
    for (uint64_t i = 0; i < unfiltered->size(); ++i) {
        REQUIRE((*without_filter)[i].id == (*unfiltered)[i].id);
        REQUIRE((*without_filter)[i].distance == (*unfiltered)[i].distance);
    }

    const auto closest_even =
        index.Search(query.data(), 2, 3, [](int64_t id) { return id % 2 == 0; });
    REQUIRE(closest_even);
    REQUIRE(closest_even->size() == 3);
    REQUIRE((*closest_even)[0].id == 1014);
    REQUIRE((*closest_even)[1].id == 1016);
    REQUIRE((*closest_even)[2].id == 1012);
    REQUIRE((*closest_even)[0].distance == 1);
    REQUIRE((*closest_even)[1].distance == 1);
    REQUIRE((*closest_even)[2].distance == 9);

    std::unordered_set<int64_t> checked_ids;
    const vsag::lite::IdFilter only_middle = [&checked_ids](int64_t id) {
        checked_ids.insert(id);
        return id == 1015;
    };
    const auto selected = index.Search(query.data(), 2, 8, only_middle);
    REQUIRE(selected);
    REQUIRE(selected->size() == 1);
    REQUIRE(selected->front().id == 1015);
    REQUIRE(selected->front().distance == 0);
    REQUIRE(checked_ids.count(1015) == 1);
    REQUIRE(checked_ids.size() > 1);

    const auto rejected = index.Search(query.data(), 2, 8, [](int64_t) { return false; });
    REQUIRE(rejected);
    REQUIRE(rejected->empty());
    REQUIRE_FALSE(index.Search(nullptr, 2, 8, only_middle));
    REQUIRE(index.Search(query.data(), 2, 0, only_middle)->empty());

    const std::array<float, 2> updated{14.5F, 0};
    REQUIRE(index.Update(1015, updated.data(), 2));
    REQUIRE(index.Remove(1001));
    const auto after_crud = index.Search(query.data(), 2, 8, only_middle);
    REQUIRE(after_crud);
    REQUIRE(after_crud->size() == 1);
    REQUIRE(after_crud->front().id == 1015);
    REQUIRE(after_crud->front().distance == 0.25F);

    std::stringstream snapshot;
    REQUIRE(index.Save(snapshot));
    auto loaded = vsag::lite::Index::Load(snapshot);
    REQUIRE(loaded);
    const auto restored = (*loaded)->Search(query.data(), 2, 8, only_middle);
    REQUIRE(restored);
    REQUIRE(restored->size() == after_crud->size());
    REQUIRE(restored->front().id == after_crud->front().id);
    REQUIRE(restored->front().distance == after_crud->front().distance);
}

TEST_CASE("Lite graph update removes obsolete reverse links", "[lite-graph]") {
    auto flat = make_brute_force_backend(2);
    REQUIRE(flat);
    for (int64_t id = 0; id < 8; ++id) {
        const std::array<float, 2> vector{static_cast<float>(id), 0};
        REQUIRE((*flat)->Add(id, vector.data(), 2));
    }
    auto graph = make_graph_backend(**flat, 2, 8);
    REQUIRE(graph);

    constexpr uint64_t updated_slot = 0;
    std::unordered_set<uint64_t> old_neighbors;
    for (uint64_t i = 0; i < (*graph)->LinkCountAt(updated_slot); ++i) {
        old_neighbors.insert((*graph)->LinkAt(updated_slot, i));
    }

    const std::array<float, 2> moved{100, 0};
    REQUIRE((*graph)->Update(0, moved.data(), 2));
    std::unordered_set<uint64_t> new_neighbors;
    for (uint64_t i = 0; i < (*graph)->LinkCountAt(updated_slot); ++i) {
        new_neighbors.insert((*graph)->LinkAt(updated_slot, i));
    }

    uint64_t obsolete = 0;
    for (uint64_t old_neighbor : old_neighbors) {
        if (new_neighbors.count(old_neighbor) != 0) {
            continue;
        }
        ++obsolete;
        bool still_linked = false;
        for (uint64_t i = 0; i < (*graph)->LinkCountAt(old_neighbor); ++i) {
            still_linked |= (*graph)->LinkAt(old_neighbor, i) == updated_slot;
        }
        REQUIRE_FALSE(still_linked);
    }
    REQUIRE(obsolete > 0);
}

TEST_CASE("Lite graph repeated CRUD repairs affected adjacency", "[lite-graph]") {
    constexpr uint64_t dim = 8;
    constexpr uint64_t count = 256;
    constexpr uint64_t max_degree = 12;
    auto flat = make_brute_force_backend(dim);
    REQUIRE(flat);
    std::mt19937 rng(20260926);
    std::normal_distribution<float> normal(0.0F, 1.0F);
    std::array<float, dim> values{};
    for (uint64_t id = 0; id < count; ++id) {
        for (float& value : values) {
            value = normal(rng);
        }
        REQUIRE((*flat)->Add(static_cast<int64_t>(id), values.data(), dim));
    }
    auto graph = make_graph_backend(**flat, max_degree, 64);
    REQUIRE(graph);
    auto edge_count = [&graph]() {
        uint64_t total = 0;
        for (uint64_t slot = 0; slot < (*graph)->Size(); ++slot) {
            total += (*graph)->LinkCountAt(slot);
        }
        return total;
    };
    auto zero_incoming = [&graph]() {
        uint64_t total = 0;
        for (uint64_t slot = 0; slot < (*graph)->Size(); ++slot) {
            total += (*graph)->IncomingLinkCountAt(slot) == 0 ? 1 : 0;
        }
        return total;
    };
    const uint64_t initial_edges = edge_count();
    for (uint64_t step = 0; step < 2000; ++step) {
        for (float& value : values) {
            value = normal(rng);
        }
        REQUIRE((*graph)->Update(static_cast<int64_t>(step), values.data(), dim));
        const uint64_t compactions = (*graph)->IncomingCompactionCount();
        const uint64_t zero_incoming_before_remove = zero_incoming();
        REQUIRE((*graph)->Remove(static_cast<int64_t>(step)));
        REQUIRE(zero_incoming() <= zero_incoming_before_remove);
        if ((*graph)->IncomingCompactionCount() != compactions) {
            REQUIRE((*graph)->IncomingCapacityBytes() - (*graph)->IncomingLogicalBytes() <=
                    (*graph)->IncomingLogicalBytes() / 4 + sizeof(uint64_t));
        }
        const uint64_t zero_incoming_before_add = zero_incoming();
        REQUIRE((*graph)->Add(static_cast<int64_t>(count + step), values.data(), dim));
        REQUIRE((*graph)->IncomingLinkCountAt((*graph)->Size() - 1) > 0);
        REQUIRE(zero_incoming() <= zero_incoming_before_add);
        require_incoming_matches(**graph);
    }
    REQUIRE((*graph)->Size() == count);
    REQUIRE((*graph)->IncomingCompactionCount() > 0);
    REQUIRE(edge_count() + max_degree >= initial_edges);
    for (uint64_t slot = 0; slot < (*graph)->Size(); ++slot) {
        for (uint64_t edge = 0; edge < (*graph)->LinkCountAt(slot); ++edge) {
            REQUIRE((*graph)->LinkAt(slot, edge) < (*graph)->Size());
            REQUIRE((*graph)->LinkAt(slot, edge) != slot);
        }
    }
}

TEST_CASE("Lite graph backend validates restored adjacency bounds", "[lite-graph]") {
    using vsag::lite::detail::restore_graph_backend;
    REQUIRE_FALSE(restore_graph_backend(0, 2, 16, {}, {}, {}));
    REQUIRE_FALSE(restore_graph_backend(
        2, 2, 16, {1, 2, 3, 4}, {0, 0, 1, 0, 0, 1, 1, 1}, {{1, 2, 3}, {0}, {0}, {0}}));
    auto empty = make_brute_force_backend(2);
    REQUIRE(empty);
    auto graph = make_graph_backend(**empty, 4, 32);
    REQUIRE(graph);
    const std::array<float, 2> query{0, 0};
    auto result = (*graph)->Search(query.data(), 2, 1);
    REQUIRE(result);
    REQUIRE(result->empty());
}

TEST_CASE("Lite graph backend randomized CRUD keeps IDs and distances valid", "[lite-graph]") {
    constexpr uint64_t dim = 8;
    auto flat = vsag::lite::Index::Create(dim);
    REQUIRE(flat);
    std::mt19937 rng(20260915);
    std::uniform_real_distribution<float> uniform(-1.0F, 1.0F);
    std::unordered_map<int64_t, std::array<float, dim>> active;
    for (int64_t id = 0; id < 200; ++id) {
        std::array<float, dim> values{};
        for (float& value : values) {
            value = uniform(rng);
        }
        REQUIRE((*flat)->Add(id, values.data(), dim));
        active.emplace(id, values);
    }
    auto graph = std::move(*flat);
    REQUIRE(graph->BuildGraph(12, 64));
    int64_t next_id = 200;
    for (uint64_t step = 0; step < 500; ++step) {
        const auto selected =
            std::next(active.begin(), static_cast<std::ptrdiff_t>(rng() % active.size()))->first;
        if (step % 3 == 0) {
            REQUIRE(graph->Remove(selected));
            active.erase(selected);
        } else {
            std::array<float, dim> values{};
            for (float& value : values) {
                value = uniform(rng);
            }
            if (step % 3 == 1) {
                REQUIRE(graph->Update(selected, values.data(), dim));
                active.at(selected) = values;
            } else {
                REQUIRE(graph->Add(next_id, values.data(), dim));
                active.emplace(next_id++, values);
            }
        }
        REQUIRE(graph->Size() == active.size());
        std::array<float, dim> query{};
        for (float& value : query) {
            value = uniform(rng);
        }
        const auto result = graph->Search(query.data(), dim, 10);
        REQUIRE(result);
        REQUIRE(result->size() == std::min<uint64_t>(10, active.size()));
        std::unordered_set<int64_t> seen;
        for (const auto& neighbor : *result) {
            REQUIRE(seen.insert(neighbor.id).second);
            const auto& vector = active.at(neighbor.id);
            float distance = 0;
            for (uint64_t d = 0; d < dim; ++d) {
                const float delta = query[d] - vector[d];
                distance += delta * delta;
            }
            REQUIRE(std::abs(distance - neighbor.distance) < 1e-4F);
        }
    }
    std::stringstream output;
    REQUIRE(graph->Save(output));
    auto restored = vsag::lite::Index::Load(output);
    REQUIRE(restored);
    REQUIRE((*restored)->ActiveBackend() == vsag::lite::BackendKind::GRAPH);
    REQUIRE((*restored)->Size() == graph->Size());
    for (uint64_t q = 0; q < 20; ++q) {
        std::array<float, dim> query{};
        for (float& value : query) {
            value = uniform(rng);
        }
        auto before = graph->Search(query.data(), dim, 10);
        auto after = (*restored)->Search(query.data(), dim, 10);
        REQUIRE(before);
        REQUIRE(after);
        REQUIRE(before->size() == after->size());
        for (uint64_t i = 0; i < before->size(); ++i) {
            REQUIRE((*before)[i].id == (*after)[i].id);
            REQUIRE((*before)[i].distance == (*after)[i].distance);
        }
    }
}

TEST_CASE("Lite graph backend recall on independent queries", "[lite-graph]") {
    constexpr uint64_t count = 1000;
    constexpr uint64_t dim = 16;
    constexpr uint64_t queries = 100;
    constexpr uint64_t k = 10;
    std::mt19937 rng(20260914);
    std::normal_distribution<float> normal(0.0F, 1.0F);
    auto flat = make_brute_force_backend(dim);
    REQUIRE(flat);
    std::vector<float> values(count * dim);
    for (uint64_t id = 0; id < count; ++id) {
        for (uint64_t d = 0; d < dim; ++d) {
            values[id * dim + d] = normal(rng);
        }
        REQUIRE((*flat)->Add(id, values.data() + id * dim, dim));
    }
    auto graph = make_graph_backend(**flat, 16, 128);
    REQUIRE(graph);
    uint64_t hits = 0;
    std::array<float, dim> query{};
    for (uint64_t q = 0; q < queries; ++q) {
        for (float& value : query) {
            value = normal(rng);
        }
        auto exact = (*flat)->Search(query.data(), dim, k);
        auto approximate = (*graph)->Search(query.data(), dim, k);
        REQUIRE(exact);
        REQUIRE(approximate);
        REQUIRE(approximate->size() == k);
        for (const auto& neighbor : *approximate) {
            hits += static_cast<uint64_t>(
                std::any_of(exact->begin(), exact->end(), [&](const auto& expected) {
                    return expected.id == neighbor.id;
                }));
        }
    }
    INFO("Recall@10=" << static_cast<double>(hits) / (queries * k));
    REQUIRE(hits >= 700);
}

namespace {
template <typename T>
std::vector<std::vector<T>>
read_sift(const std::string& path, int32_t expected_dim) {
    std::ifstream input(path, std::ios::binary);
    REQUIRE(input);
    std::vector<std::vector<T>> rows;
    int32_t dim = 0;
    while (input.read(reinterpret_cast<char*>(&dim), sizeof(dim))) {
        REQUIRE(dim == expected_dim);
        std::vector<T> row(dim);
        input.read(reinterpret_cast<char*>(row.data()), sizeof(T) * dim);
        REQUIRE(input);
        rows.push_back(std::move(row));
    }
    REQUIRE(input.eof());
    return rows;
}
uint64_t
current_rss_kib() {
    std::ifstream status("/proc/self/status");
    std::string line;
    while (std::getline(status, line)) {
        if (line.rfind("VmRSS:", 0) == 0) {
            std::istringstream fields(line);
            std::string key;
            uint64_t value = 0;
            std::string unit;
            fields >> key >> value >> unit;
            REQUIRE(unit == "kB");
            return value;
        }
    }
    FAIL("VmRSS is unavailable");
    return 0;
}

void
trim_heap() {
#if defined(__GLIBC__)
    malloc_trim(0);
#endif
}
}  // namespace

TEST_CASE("Lite public FP16 graph CRUD and v3 snapshot", "[lite-graph]") {
    using vsag::lite::Index;
    using vsag::lite::VectorStorage;
    auto created = Index::Create(2);
    const std::array<float, 2> a{0.125F, -0.25F};
    const std::array<float, 2> b{1.5F, 2.0F};
    const std::array<float, 2> c{-3.0F, 4.0F};
    REQUIRE((*created)->Add(10, a.data(), 2));
    REQUIRE((*created)->Add(20, b.data(), 2));
    REQUIRE((*created)->Add(30, c.data(), 2));
    REQUIRE((*created)->BuildGraph(VectorStorage::FP16, 4, 32));
    REQUIRE((*created)->ActiveVectorStorage() == VectorStorage::FP16);
    REQUIRE((*created)->Update(20, a.data(), 2));
    REQUIRE((*created)->Remove(30));
    REQUIRE((*created)->Add(40, c.data(), 2));
    const auto before = (*created)->Search(a.data(), 2, 3, [](int64_t id) { return id != 10; });
    REQUIRE(before);
    std::stringstream output;
    REQUIRE((*created)->Save(output));
    const auto bytes = output.str();
    REQUIRE(static_cast<unsigned char>(bytes[8]) == 3);
    REQUIRE(static_cast<unsigned char>(bytes[40]) == 3);
    auto loaded = Index::Load(output);
    REQUIRE(loaded);
    REQUIRE((*loaded)->ActiveVectorStorage() == VectorStorage::FP16);
    const auto after = (*loaded)->Search(a.data(), 2, 3, [](int64_t id) { return id != 10; });
    REQUIRE(after);
    REQUIRE(after->size() == before->size());
    for (uint64_t i = 0; i < after->size(); ++i) {
        REQUIRE((*after)[i].id == (*before)[i].id);
        REQUIRE((*after)[i].distance == (*before)[i].distance);
    }
    for (uint64_t n = 0; n < bytes.size(); ++n) {
        std::stringstream truncated(bytes.substr(0, n));
        REQUIRE_FALSE(Index::Load(truncated));
    }
    auto nonfinite = bytes;
    constexpr uint64_t vector_offset = 48 + 16 + 3 * 8;
    nonfinite[vector_offset] = 1;
    nonfinite[vector_offset + 1] = static_cast<char>(0x7c);
    std::stringstream invalid_half(nonfinite);
    REQUIRE_FALSE(Index::Load(invalid_half));
    auto bad_representation = bytes;
    bad_representation[40] = 2;
    std::stringstream invalid_representation(bad_representation);
    REQUIRE_FALSE(Index::Load(invalid_representation));
}

TEST_CASE("Lite graph public transition and v2 snapshot roundtrip", "[lite-graph]") {
    using vsag::lite::BackendKind;
    using vsag::lite::Index;
    auto created = Index::Create(2);
    REQUIRE(created);
    auto& index = **created;
    REQUIRE(index.ActiveBackend() == BackendKind::BRUTE_FORCE);
    std::array<float, 2> a{0, 0};
    std::array<float, 2> b{1, 0};
    std::array<float, 2> c{0, 1};
    REQUIRE(index.Add(-1, a.data(), 2));
    REQUIRE(index.Add(2, b.data(), 2));
    REQUIRE(index.Add(3, c.data(), 2));
    REQUIRE_FALSE(index.BuildGraph(1, 8));
    REQUIRE(index.ActiveBackend() == BackendKind::BRUTE_FORCE);
    REQUIRE(index.Size() == 3);
    REQUIRE(index.BuildGraph(4, 32));
    REQUIRE(index.ActiveBackend() == BackendKind::GRAPH);
    REQUIRE_FALSE(index.BuildGraph());
    REQUIRE(index.Update(2, a.data(), 2));
    REQUIRE(index.Remove(3));
    REQUIRE(index.Add(4, c.data(), 2));
    std::stringstream output;
    REQUIRE(index.Save(output));
    const auto bytes = output.str();
    REQUIRE(bytes.substr(0, 8) == "VSAGLT01");
    REQUIRE(static_cast<unsigned char>(bytes[8]) == 2);
    REQUIRE(static_cast<unsigned char>(bytes[40]) == 2);
    std::stringstream input(bytes);
    auto loaded = Index::Load(input);
    REQUIRE(loaded);
    REQUIRE((*loaded)->ActiveBackend() == BackendKind::GRAPH);
    REQUIRE((*loaded)->Size() == index.Size());
    for (const auto& query : {a, b, c}) {
        auto before = index.Search(query.data(), 2, 3);
        auto after = (*loaded)->Search(query.data(), 2, 3);
        REQUIRE(before);
        REQUIRE(after);
        REQUIRE(before->size() == after->size());
        for (uint64_t i = 0; i < before->size(); ++i) {
            REQUIRE((*before)[i].id == (*after)[i].id);
            REQUIRE((*before)[i].distance == (*after)[i].distance);
        }
    }
    auto corrupt = bytes;
    corrupt.push_back('x');
    std::stringstream extra(corrupt);
    REQUIRE_FALSE(Index::Load(extra));
    for (uint64_t n = 0; n < bytes.size(); ++n) {
        std::stringstream truncated(bytes.substr(0, n));
        REQUIRE_FALSE(Index::Load(truncated));
    }
    corrupt = bytes;
    corrupt[48] = 1;  // degree below 2
    std::stringstream bad_degree(corrupt);
    REQUIRE_FALSE(Index::Load(bad_degree));
    corrupt = bytes;
    corrupt.replace(72, 8, corrupt.substr(64, 8));  // duplicate ID
    std::stringstream duplicate_id(corrupt);
    REQUIRE_FALSE(Index::Load(duplicate_id));
    corrupt = bytes;
    corrupt[88] = 0;
    corrupt[89] = 0;
    corrupt[90] = static_cast<char>(0xc0);
    corrupt[91] = 0x7f;  // NaN vector
    std::stringstream nonfinite(corrupt);
    REQUIRE_FALSE(Index::Load(nonfinite));
    corrupt = bytes;
    corrupt[112] = 65;  // link count above maximum degree
    std::stringstream bad_degree_count(corrupt);
    REQUIRE_FALSE(Index::Load(bad_degree_count));
    corrupt = bytes;
    REQUIRE(static_cast<unsigned char>(corrupt[112]) > 0);
    corrupt[120] = static_cast<char>(0xff);  // first adjacency target outside index
    std::stringstream bad_neighbor(corrupt);
    REQUIRE_FALSE(Index::Load(bad_neighbor));
    corrupt = bytes;
    corrupt[120] = 0;  // self-link at slot zero
    std::stringstream self_link(corrupt);
    REQUIRE_FALSE(Index::Load(self_link));
    corrupt = bytes;
    REQUIRE(static_cast<unsigned char>(corrupt[112]) >= 2);
    corrupt.replace(128, 8, corrupt.substr(120, 8));  // duplicate adjacency target
    std::stringstream duplicate_link(corrupt);
    REQUIRE_FALSE(Index::Load(duplicate_link));
    corrupt = bytes;
    corrupt[56] = 1;  // ef_search below degree
    std::stringstream bad_ef(corrupt);
    REQUIRE_FALSE(Index::Load(bad_ef));
    corrupt = bytes;
    corrupt[32] ^= 1;  // mismatched payload length
    std::stringstream bad_payload(corrupt);
    REQUIRE_FALSE(Index::Load(bad_payload));

    auto empty = Index::Create(2);
    REQUIRE((*empty)->BuildGraph());
    std::stringstream empty_output;
    REQUIRE((*empty)->Save(empty_output));
    auto empty_loaded = Index::Load(empty_output);
    REQUIRE(empty_loaded);
    REQUIRE((*empty_loaded)->ActiveBackend() == BackendKind::GRAPH);
    REQUIRE((*empty_loaded)->Size() == 0);
}

TEST_CASE("Lite graph SIFT independent-query probe", "[.][lite-sift]") {
    const char* directory = std::getenv("VSAG_SIFT_DIR");
    REQUIRE(directory != nullptr);
    const char* storage_name = std::getenv("VSAG_GRAPH_STORAGE");
    const std::string selected = storage_name == nullptr ? "fp32" : storage_name;
    REQUIRE((selected == "fp32" or selected == "fp16"));
    const auto storage =
        selected == "fp16" ? vsag::lite::VectorStorage::FP16 : vsag::lite::VectorStorage::FP32;
    const std::string root(directory);
    const auto base = read_sift<float>(root + "/base.fvecs", 128);
    const auto queries = read_sift<float>(root + "/queries.fvecs", 128);
    const auto truth = read_sift<int32_t>(root + "/groundtruth.ivecs", 10);
    REQUIRE(queries.size() == truth.size());
    auto graph = vsag::lite::Index::Create(128);
    REQUIRE(graph);
    for (uint64_t id = 0; id < base.size(); ++id) {
        REQUIRE((*graph)->Add(id, base[id].data(), 128));
    }
    auto start = std::chrono::steady_clock::now();
    REQUIRE((*graph)->BuildGraph(storage, 16, 128));
    const auto build_ms =
        std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    std::vector<double> latency;
    std::vector<std::vector<vsag::lite::Neighbor>> before;
    uint64_t hits = 0;
    for (uint64_t q = 0; q < queries.size(); ++q) {
        start = std::chrono::steady_clock::now();
        auto result = (*graph)->Search(queries[q].data(), 128, 10);
        latency.push_back(
            std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - start)
                .count());
        REQUIRE(result);
        REQUIRE(result->size() == 10);
        const std::unordered_set<int64_t> expected(truth[q].begin(), truth[q].end());
        for (const auto& neighbor : *result) {
            hits += expected.count(neighbor.id);
        }
        before.push_back(std::move(*result));
    }
    const char* snapshot_path = std::getenv("VSAG_GRAPH_SNAPSHOT");
    REQUIRE(snapshot_path != nullptr);
    start = std::chrono::steady_clock::now();
    std::ofstream output(snapshot_path, std::ios::binary);
    REQUIRE(output);
    REQUIRE((*graph)->Save(output));
    output.close();
    REQUIRE(output);
    const auto save_ms =
        std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    start = std::chrono::steady_clock::now();
    std::ifstream input(snapshot_path, std::ios::binary);
    auto loaded = vsag::lite::Index::Load(input);
    REQUIRE(loaded);
    const auto load_ms =
        std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    REQUIRE((*loaded)->ActiveBackend() == vsag::lite::BackendKind::GRAPH);
    REQUIRE((*loaded)->ActiveVectorStorage() == storage);
    for (uint64_t q = 0; q < queries.size(); ++q) {
        auto after = (*loaded)->Search(queries[q].data(), 128, 10);
        REQUIRE(after);
        REQUIRE(after->size() == before[q].size());
        for (uint64_t i = 0; i < after->size(); ++i) {
            REQUIRE((*after)[i].id == before[q][i].id);
            REQUIRE((*after)[i].distance == before[q][i].distance);
        }
    }
    std::sort(latency.begin(), latency.end());
    std::cout << "storage,base_count,query_count,degree,ef,recall_at_10,build_ms,"
                 "search_p50_us,search_p99_us,save_ms,load_ms,snapshot_bytes\n";
    std::cout << selected << ',' << base.size() << ',' << queries.size() << ",16,128,"
              << static_cast<double>(hits) / static_cast<double>(queries.size() * 10) << ','
              << build_ms << ',' << latency[(latency.size() - 1) / 2] << ','
              << latency[(latency.size() * 99 - 1) / 100] << ',' << save_ms << ',' << load_ms << ','
              << std::filesystem::file_size(snapshot_path) << '\n';
    REQUIRE(hits >= queries.size() * 5);
}

TEST_CASE("Lite graph SIFT isolated RSS probe", "[.][lite-sift-rss]") {
    const char* directory = std::getenv("VSAG_SIFT_DIR");
    const char* backend = std::getenv("VSAG_SIFT_RSS_BACKEND");
    REQUIRE(directory != nullptr);
    REQUIRE(backend != nullptr);
    const std::string root(directory);
    auto base = read_sift<float>(root + "/base.fvecs", 128);
    const auto queries = read_sift<float>(root + "/queries.fvecs", 128);
    const auto truth = read_sift<int32_t>(root + "/groundtruth.ivecs", 10);
    const uint64_t base_count = base.size();
    auto index = vsag::lite::Index::Create(128);
    REQUIRE(index);
    for (uint64_t id = 0; id < base_count; ++id) {
        REQUIRE((*index)->Add(id, base[id].data(), 128));
    }
    const std::string selected(backend);
    REQUIRE((selected == "fp32" or selected == "fp16"));
    const auto storage =
        selected == "fp16" ? vsag::lite::VectorStorage::FP16 : vsag::lite::VectorStorage::FP32;
    REQUIRE((*index)->BuildGraph(storage, 16, 128));
    std::vector<std::vector<float>>().swap(base);
    trim_heap();
    uint64_t hits = 0;
    for (uint64_t q = 0; q < queries.size(); ++q) {
        const auto result = (*index)->Search(queries[q].data(), 128, 10);
        REQUIRE(result);
        const std::unordered_set<int64_t> expected(truth[q].begin(), truth[q].end());
        for (const auto& neighbor : *result) {
            hits += expected.count(neighbor.id);
        }
    }
    trim_heap();
    std::cout << "backend,base_count,query_count,recall_at_10,steady_rss_kib\n";
    std::cout << backend << ',' << base_count << ',' << queries.size() << ','
              << static_cast<double>(hits) / static_cast<double>(queries.size() * 10) << ','
              << current_rss_kib() << '\n';
    REQUIRE(hits >= queries.size() * 5);
}

TEST_CASE("Lite graph SIFT fresh-process load probe", "[.][lite-sift-load]") {
    const char* directory = std::getenv("VSAG_SIFT_DIR");
    const char* snapshot_path = std::getenv("VSAG_GRAPH_SNAPSHOT");
    REQUIRE(directory != nullptr);
    REQUIRE(snapshot_path != nullptr);
    const std::string root(directory);
    const auto queries = read_sift<float>(root + "/queries.fvecs", 128);
    const auto truth = read_sift<int32_t>(root + "/groundtruth.ivecs", 10);
    REQUIRE(queries.size() == truth.size());
    REQUIRE(queries.size() > 1);
    auto start = std::chrono::steady_clock::now();
    std::ifstream input(snapshot_path, std::ios::binary);
    auto loaded = vsag::lite::Index::Load(input);
    REQUIRE(loaded);
    REQUIRE((*loaded)->ActiveBackend() == vsag::lite::BackendKind::GRAPH);
    const auto storage = (*loaded)->ActiveVectorStorage();
    REQUIRE(
        (storage == vsag::lite::VectorStorage::FP32 or storage == vsag::lite::VectorStorage::FP16));
    const char* const storage_name = storage == vsag::lite::VectorStorage::FP16 ? "fp16" : "fp32";
    const auto load_ms =
        std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
    uint64_t hits = 0;
    double first_query_us = 0;
    std::vector<double> follow_up_latency;
    for (uint64_t q = 0; q < queries.size(); ++q) {
        start = std::chrono::steady_clock::now();
        auto result = (*loaded)->Search(queries[q].data(), 128, 10);
        const auto elapsed_us =
            std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now() - start)
                .count();
        if (q == 0) {
            first_query_us = elapsed_us;
        } else {
            follow_up_latency.push_back(elapsed_us);
        }
        REQUIRE(result);
        REQUIRE(result->size() == 10);
        const std::unordered_set<int64_t> expected(truth[q].begin(), truth[q].end());
        for (const auto& neighbor : *result) {
            hits += expected.count(neighbor.id);
        }
    }
    std::sort(follow_up_latency.begin(), follow_up_latency.end());
    trim_heap();
    const auto steady_rss_kib = current_rss_kib();
    rusage usage{};
    REQUIRE(getrusage(RUSAGE_SELF, &usage) == 0);
    std::cout << "storage,query_count,recall_at_10,load_ms,first_query_us,search_p50_us,"
                 "search_p99_us,steady_rss_kib,process_peak_rss_kib,snapshot_bytes\n";
    std::cout << storage_name << ',' << queries.size() << ','
              << static_cast<double>(hits) / static_cast<double>(queries.size() * 10) << ','
              << load_ms << ',' << first_query_us << ','
              << follow_up_latency[(follow_up_latency.size() - 1) / 2] << ','
              << follow_up_latency[(follow_up_latency.size() * 99 - 1) / 100] << ','
              << steady_rss_kib << ',' << usage.ru_maxrss << ','
              << std::filesystem::file_size(snapshot_path) << '\n';
    REQUIRE(hits >= queries.size() * 5);
}

#if defined(VSAG_LITE_EXPERIMENT_DIVERSE_NEIGHBORS)
TEST_CASE("Experimental online diversity excludes collinear redundant neighbors",
          "[lite-graph][diverse-experiment]") {
    auto flat = make_brute_force_backend(1);
    REQUIRE(flat);
    for (int64_t id = 0; id < 3; ++id) {
        const auto vector = static_cast<float>(id);
        REQUIRE((*flat)->Add(id, &vector, 1));
    }
    auto graph = make_graph_backend(**flat, 2, 8);
    REQUIRE(graph);
    auto fp16 = make_fp16_graph_backend(**flat, 2, 8);
    REQUIRE(fp16);
    const float inserted = 3.0F;
    REQUIRE((*fp16)->Add(3, &inserted, 1));
    REQUIRE((*fp16)->LinkCountAt(3) == 2);
    require_incoming_matches(**fp16);
    REQUIRE((*graph)->Add(3, &inserted, 1));
    REQUIRE((*graph)->LinkCountAt(3) == 1);
    REQUIRE((*graph)->IdAt((*graph)->LinkAt(3, 0)) == 2);
    require_incoming_matches(**graph);
    const float updated = 4.0F;
    REQUIRE((*graph)->Update(3, &updated, 1));
    REQUIRE((*graph)->LinkCountAt(3) == 1);
    REQUIRE((*graph)->IdAt((*graph)->LinkAt(3, 0)) == 2);
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Remove(1));
    require_incoming_matches(**graph);
    REQUIRE((*graph)->Search(&updated, 1, 1)->front().id == 3);
}
#endif

TEST_CASE("Lite FP16 snapshots preserve every finite binary16 encoding", "[lite-graph]") {
    using vsag::lite::Index;
    std::vector<uint16_t> bits;
    std::vector<float> values;
    for (uint64_t value = 0; value < 65536; ++value) {
        const auto encoded = static_cast<uint16_t>(value);
        if (vsag::lite::detail::is_finite_fp16(encoded)) {
            bits.push_back(encoded);
            values.push_back(vsag::lite::detail::decode_fp16(encoded));
            REQUIRE(vsag::lite::detail::encode_fp16(values.back()) == encoded);
        }
    }
    REQUIRE(bits.size() == 63488);
    auto index = Index::Create(values.size());
    REQUIRE(index);
    REQUIRE((*index)->Add(17, values.data(), values.size()));
    REQUIRE((*index)->BuildGraph(vsag::lite::VectorStorage::FP16, 2, 2));
    std::stringstream output;
    REQUIRE((*index)->Save(output));
    const auto snapshot = output.str();
    constexpr uint64_t vector_offset = 72;  // v3 header + graph options + one ID.
    for (uint64_t i = 0; i < bits.size(); ++i) {
        REQUIRE(static_cast<uint8_t>(snapshot[vector_offset + 2 * i]) == (bits[i] & 255U));
        REQUIRE(static_cast<uint8_t>(snapshot[vector_offset + 2 * i + 1]) == (bits[i] >> 8U));
    }
    auto restored = Index::Load(output);
    REQUIRE(restored);
    std::stringstream again;
    REQUIRE((*restored)->Save(again));
    REQUIRE(again.str() == snapshot);
}

TEST_CASE("Lite restore rejects invalid layouts and duplicate FP16 IDs", "[lite-graph]") {
    REQUIRE_FALSE(vsag::lite::detail::restore_brute_force_backend(0, {1}, {1.0F}));
    REQUIRE_FALSE(vsag::lite::detail::restore_brute_force_backend(1, {1}, {}));
    REQUIRE_FALSE(
        vsag::lite::detail::restore_fp16_graph_backend(1, 2, 8, {1, 1}, {0, 0}, {{}, {}}));
}

TEST_CASE("Lite FP16 restore and conversion reject unsafe inputs", "[lite-graph]") {
    using vsag::lite::detail::restore_fp16_graph_backend;
    REQUIRE_FALSE(restore_fp16_graph_backend(1, 2, 8, {1}, {}, {{}}));
    REQUIRE_FALSE(restore_fp16_graph_backend(1, 2, 8, {1, 2}, {0, 0}, {{0}, {}}));
    REQUIRE_FALSE(
        restore_fp16_graph_backend(1, 2, 8, {1, 2, 3, 4}, {0, 0, 0, 0}, {{1, 2, 3}, {}, {}, {}}));
    auto flat = make_brute_force_backend(1);
    REQUIRE(flat);
    const float huge = 70000.0F;
    REQUIRE((*flat)->Add(17, &huge, 1));
    REQUIRE_FALSE(make_fp16_graph_backend(**flat, 2, 8));
    REQUIRE_FALSE(make_fp16_graph_backend(**flat, 1, 8));
    const float small = 1.0F;
    REQUIRE((*flat)->Update(17, &small, 1));
    auto graph = make_fp16_graph_backend(**flat, 2, 8);
    REQUIRE(graph);
    REQUIRE_FALSE((*graph)->Search(&huge, 1, 1));
    REQUIRE((*graph)->Search(&small, 1, 1)->front().id == 17);
}

TEST_CASE("Lite update repairs old outgoing targets that lose their only incoming edge",
          "[lite-graph]") {
    const std::vector<int64_t> ids{0, 1, 2, 3};
    const std::vector<float> vectors{0.0F, 100.0F, 1.0F, 2.0F};
    const std::vector<std::vector<uint64_t>> links{{1, 2}, {2, 3}, {0, 3}, {0, 2}};
    for (const bool fp16 : {false, true}) {
        for (const float replacement : {0.0F, 0.25F}) {
            auto graph =
                fp16 ? vsag::lite::detail::restore_fp16_graph_backend(
                           1,
                           2,
                           128,
                           ids,
                           {vsag::lite::detail::encode_fp16(0.0F),
                            vsag::lite::detail::encode_fp16(100.0F),
                            vsag::lite::detail::encode_fp16(1.0F),
                            vsag::lite::detail::encode_fp16(2.0F)},
                           links)
                     : vsag::lite::detail::restore_graph_backend(1, 2, 128, ids, vectors, links);
            REQUIRE(graph);
            REQUIRE((*graph)->IncomingLinkCountAt(1) == 1);
            require_incoming_matches(**graph);
            REQUIRE((*graph)->Update(0, &replacement, 1));
            REQUIRE((*graph)->IncomingLinkCountAt(1) > 0);
            require_incoming_matches(**graph);
            for (uint64_t slot = 0; slot < (*graph)->Size(); ++slot) {
                REQUIRE((*graph)->LinkCountAt(slot) <= 2);
                REQUIRE((*graph)->IncomingLinkCountAt(slot) > 0);
            }
            const float query = 100.0F;
            auto found = (*graph)->Search(&query, 1, 4);
            REQUIRE(found);
            REQUIRE(found->size() == 4);
            REQUIRE(found->front().id == 1);
            REQUIRE(found->front().distance == 0.0F);
            const vsag::lite::IdFilter only_target = [](int64_t id) { return id == 1; };
            auto filtered = (*graph)->Search(&query, 1, 1, only_target);
            REQUIRE(filtered);
            REQUIRE(filtered->size() == 1);
            REQUIRE(filtered->front().id == 1);
        }
    }
}

TEST_CASE("Lite routing admission must not discard allowed coarse-rejected entries",
          "[lite-graph]") {
    for (const auto storage : {vsag::lite::VectorStorage::FP32, vsag::lite::VectorStorage::FP16}) {
        auto created = vsag::lite::Index::Create(1);
        REQUIRE(created);
        for (int64_t id = 0; id < 64; ++id) {
            const auto value = static_cast<float>(id);
            REQUIRE((*created)->Add(id, &value, 1));
        }
        REQUIRE((*created)->BuildGraph(storage, 4, 16));
        const float query = 0;
        const vsag::lite::SearchOptions options{4};
        // Entry54 is encountered after the best heap is full of closer entries.
        auto result = (*created)->SearchWithOptions(
            &query, 1, 1, options, [](int64_t id) { return id == 54; });
        REQUIRE(result);
        REQUIRE(result->size() == 1);
        REQUIRE(result->front().id == 54);
        REQUIRE(result->front().distance == 2916.0F);
        auto rejected =
            (*created)->SearchWithOptions(&query, 1, 1, options, [](int64_t) { return false; });
        REQUIRE(rejected);
        REQUIRE(rejected->empty());
    }
}

namespace {
class ScratchRowsBackend final : public vsag::lite::detail::Backend {
public:
    explicit ScratchRowsBackend(const Backend& source, bool invalid = false)
        : source_(source), invalid_(invalid) {
    }
    tl::expected<void, vsag::Error>
    Add(int64_t /*id*/, const float* /*vector*/, uint64_t /*dim*/) override {
        return tl::unexpected(
            vsag::Error(vsag::ErrorType::UNSUPPORTED_INDEX_OPERATION, "read only"));
    }
    tl::expected<void, vsag::Error>
    Update(int64_t id, const float* vector, uint64_t dim) override {
        return Add(id, vector, dim);
    }
    bool
    Remove(int64_t /*id*/) override {
        return false;
    }
    tl::expected<std::vector<vsag::lite::Neighbor>, vsag::Error>
    Search(const float* query, uint64_t dim, uint64_t k) const override {
        return source_.Search(query, dim, k);
    }
    tl::expected<std::vector<vsag::lite::Neighbor>, vsag::Error>
    Search(const float* query,
           uint64_t dim,
           uint64_t k,
           const vsag::lite::IdFilter& filter) const override {
        return source_.Search(query, dim, k, filter);
    }
    [[nodiscard]] uint64_t
    Size() const override {
        return source_.Size();
    }
    [[nodiscard]] uint64_t
    Dim() const override {
        return source_.Dim();
    }
    [[nodiscard]] int64_t
    IdAt(uint64_t slot) const override {
        return source_.IdAt(slot);
    }
    [[nodiscard]] vsag::lite::BackendKind
    Kind() const override {
        return source_.Kind();
    }
    const float*
    VectorAt(uint64_t slot, std::vector<float>& scratch) const override {
        std::vector<float> original;
        const auto* row = source_.VectorAt(slot, original);
        scratch.assign(row, row + Dim());
        if (invalid_ and slot + 1 == Size()) {
            scratch.front() = std::numeric_limits<float>::quiet_NaN();
        }
        return scratch.data();
    }

private:
    const Backend& source_;
    bool invalid_;
};
}  // namespace

TEST_CASE("Lite borrowed topology matches owned graph and outlives its source", "[lite-graph]") {
    using vsag::lite::detail::build_graph_topology;
    for (const uint64_t dim : {1ULL, 17ULL, 128ULL, 768ULL}) {
        auto flat = make_brute_force_backend(dim);
        REQUIRE(flat);
        std::vector<float> vector(dim);
        for (uint64_t slot = 0; slot < 32; ++slot) {
            const uint64_t duplicate_row = slot / 2;
            for (uint64_t d = 0; d < dim; ++d) {
                vector[d] = std::sin(static_cast<float>(duplicate_row * 13 + d) * .17F);
            }
            REQUIRE((*flat)->Add(100 - static_cast<int64_t>(slot * 7), vector.data(), dim));
        }
        auto owned = make_graph_backend(**flat, 4, 16);
        REQUIRE(owned);
        ScratchRowsBackend scratch(**flat);
        auto borrowed = build_graph_topology(**flat, 4, 16);
        auto buffered = build_graph_topology(scratch, 4, 16);
        REQUIRE(borrowed);
        REQUIRE(buffered);
        REQUIRE(*borrowed == *buffered);
        ScratchRowsBackend invalid(**flat, true);
        REQUIRE_FALSE(build_graph_topology(invalid, 4, 16));
        REQUIRE((*flat)->Size() == 32);
        REQUIRE_FALSE(build_graph_topology(**flat, 1, 16));
        REQUIRE_FALSE(build_graph_topology(**flat, 4, 2));
        REQUIRE_FALSE(build_graph_topology(**owned, 4, 16));
        flat->reset();
        for (uint64_t slot = 0; slot < (*owned)->Size(); ++slot) {
            REQUIRE((*borrowed)[slot].size() == (*owned)->LinkCountAt(slot));
            for (uint64_t edge = 0; edge < (*borrowed)[slot].size(); ++edge) {
                REQUIRE((*borrowed)[slot][edge] == (*owned)->LinkAt(slot, edge));
            }
        }
    }
    auto empty = make_brute_force_backend(1);
    REQUIRE(empty);
    auto links = build_graph_topology(**empty, 2, 2);
    REQUIRE(links);
    REQUIRE(links->empty());
}

TEST_CASE("Lite query heap data preserves priority queue contents", "[lite-graph]") {
    using Record = std::pair<float, uint64_t>;
    const auto check = [](auto compare) {
        for (uint64_t capacity : {0ULL, 1ULL, 2ULL, 3ULL, 16ULL, 512ULL}) {
            std::priority_queue<Record, std::vector<Record>, decltype(compare)> reference(compare);
            vsag::lite::detail::QueryHeap<Record, decltype(compare)> candidate(compare);
            std::mt19937 random(47);
            for (uint64_t step = 0; step < 2000; ++step) {
                const Record value{static_cast<float>(random() % 17), random() % 31};
                if (capacity != 0) {
                    reference.push(value);
                    candidate.push(value);
                    if (reference.size() > capacity) {
                        reference.pop();
                        candidate.pop();
                    }
                }
                REQUIRE(candidate.size() == reference.size());
                REQUIRE(candidate.GetData().size() == reference.size());
                if (not reference.empty()) {
                    REQUIRE(candidate.top() == reference.top());
                }
                if (step % 37 == 0) {
                    auto expected = reference;
                    auto actual = candidate;
                    auto values = actual.TakeData();
                    std::sort(
                        values.begin(), values.end(), [&](const auto& left, const auto& right) {
                            return compare(right, left);
                        });
                    REQUIRE(values.size() == expected.size());
                    for (const auto& value : values) {
                        REQUIRE(value == expected.top());
                        expected.pop();
                    }
                    REQUIRE(expected.empty());
                }
            }
        }
    };
    check(std::less<Record>{});
    check(std::greater<Record>{});
}
