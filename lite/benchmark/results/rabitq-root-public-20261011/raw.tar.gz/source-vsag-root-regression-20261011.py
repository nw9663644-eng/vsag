"""Replay the existing public CRUD/filter/tie/snapshot fixture against both libraries."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

repo=Path('/home/ubuntu/project/vsag-lite-baseline-v01')
out=repo / 'lite/benchmark/results/rabitq-root-public-20261011'
build=repo / 'build-lite-fp16-simd-release'
control=Path('/home/ubuntu/project/vsag-root-control-c55466b')
commands=[]
with tempfile.TemporaryDirectory(prefix='vsag-visited-regression-',dir='/dev/shm') as directory:
    scratch=Path(directory)
    binary=scratch / 'regression'
    result=subprocess.run(['c++','-O2','-std=c++17','-Iinclude','lite/benchmark/graph_heap_regression.cpp',
        '-L'+str(build),'-lvsag-lite','-o',str(binary)],cwd=repo,capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    for storage in ['fp32','fp16','rabitq8']:
        results={}
        ledgers={}
        for variant,path in [('control',control),('candidate',build)]:
            env=dict(os.environ,LD_LIBRARY_PATH=str(path),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
            ledger=scratch / (storage+'-'+variant+'.ledger')
            argv=['taskset','-c','0',str(binary),storage,str(ledger)]
            result=subprocess.run(argv,cwd=repo,env=env,capture_output=True)
            assert result.returncode==0,result.stderr
            (out / ('regression-'+storage+'-'+variant+'.csv')).write_bytes(result.stdout)
            results[variant]=hashlib.sha256(result.stdout).hexdigest()
            ledgers[variant]=hashlib.sha256(ledger.read_bytes()).hexdigest()
            commands.append(dict(storage=storage,variant=variant,argv=argv,exit=0,
                stdout_sha256=results[variant],ledger_sha256=ledgers[variant],ledger_bytes=ledger.stat().st_size))
        assert results['control']==results['candidate'] and ledgers['control']==ledgers['candidate']
    (out / 'regression.json').write_text(json.dumps(dict(status='PASS',commands=commands,
        scope='existing 96-node fixture; 1/17/128 dimensions; repeated true-value CRUD; ties/external IDs/filter/SaveLoad; byte path only'),indent=2)+'\n')
print('PASS 3 storages exact fixture output and snapshot ledger SHA; byte path only',flush=True)
