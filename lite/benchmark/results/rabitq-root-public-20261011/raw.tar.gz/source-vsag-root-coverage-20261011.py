"""Fresh coverage of Lite sources, merging line hits across all local test TUs."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile

repo=Path('/home/ubuntu/project/vsag-lite-baseline-v01')
build=repo / 'build-lite-fp16-simd-coverage'
out=Path('/home/ubuntu/project/vsag-root-validation-20261011')
out.mkdir(exist_ok=False)

def run(tag,args,cwd):
    result=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True)
    (out / (tag+'.stdout')).write_text(result.stdout)
    (out / (tag+'.stderr')).write_text(result.stderr)
    assert result.returncode==0,(tag,result.stderr)

run('build',['cmake','--build',build,'-j2'],repo)
reset=[]
for path in sorted(build.rglob('*.gcda')):
    resolved=path.resolve()
    assert resolved.is_relative_to(build.resolve()) and resolved.is_file()
    reset.append(dict(path=str(resolved),sha256=hashlib.sha256(resolved.read_bytes()).hexdigest()))
    resolved.unlink()
(out / 'reset-counters.json').write_text(json.dumps(reset,indent=2)+'\n')
run('test',['ctest','--test-dir',build,'--output-on-failure'],repo)
merged={}
with tempfile.TemporaryDirectory(prefix='vsag-bitmap-gcov-',dir='/dev/shm') as directory:
    scratch=Path(directory)
    for number,note in enumerate(sorted(build.rglob('*.gcno'))):
        if not note.with_suffix('.gcda').exists():
            continue
        target=scratch / str(number)
        target.mkdir()
        run('gcov-'+str(number),['gcov','--json-format',note],target)
        for path in target.glob('*.gcov.json.gz'):
            data=json.loads(gzip.decompress(path.read_bytes()))
            for record in data['files']:
                file=Path(record['file'])
                if not file.is_absolute():
                    file=repo / file
                if not file.is_relative_to(repo / 'src/lite') and not file.is_relative_to(repo / 'include/vsag/lite'):
                    continue
                if file.name.endswith('_test.cpp'):
                    continue
                name=str(file.relative_to(repo))
                hits=merged.setdefault(name,{})
                for line in record['lines']:
                    hits[line['line_number']]=hits.get(line['line_number'],False) or line['count']>0
summary={name:dict(total=len(lines),covered=sum(lines.values())) for name,lines in merged.items()}
total=sum(item['total'] for item in summary.values())
covered=sum(item['covered'] for item in summary.values())
report=dict(scope='src/lite + include/vsag/lite non-test line union; fresh counters; not whole native Full',
    files=summary,total=total,covered=covered,percent=covered*100/total)
(out / 'coverage.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
assert report['percent']>=90
assert summary['src/lite/query_visited.h']['covered']==summary['src/lite/query_visited.h']['total']
