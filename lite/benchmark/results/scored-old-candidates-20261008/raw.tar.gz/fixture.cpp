// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>

#include "lite/backend.h"
#include "lite/fp16_codec.h"

void
check(bool ok, const char* reason) {
    if (not ok) {
        throw std::runtime_error(reason);
    }
}
void
validate(const vsag::lite::detail::Backend& graph) {
    std::vector<std::vector<uint64_t>> incoming(graph.Size());
    for (uint64_t a = 0; a < graph.Size(); ++a) {
        check(graph.LinkCountAt(a) <= 2, "degree exceeded");
        std::unordered_set<uint64_t> unique;
        for (uint64_t rank = 0; rank < graph.LinkCountAt(a); ++rank) {
            const uint64_t b = graph.LinkAt(a, rank);
            check(b < graph.Size() and b != a and unique.insert(b).second, "invalid edge");
            incoming[b].push_back(a);
        }
    }
    for (uint64_t b = 0; b < graph.Size(); ++b) {
        std::vector<uint64_t> actual;
        for (uint64_t rank = 0; rank < graph.IncomingLinkCountAt(b); ++rank) {
            actual.push_back(graph.IncomingLinkAt(b, rank));
        }
        std::sort(actual.begin(), actual.end());
        std::sort(incoming[b].begin(), incoming[b].end());
        check(actual == incoming[b], "incoming mismatch");
    }
}
int
main(int argc, char** argv) {
    try {
        check(argc == 2, "expected on/off");
        const bool enabled = std::string(argv[1]) == "on";
        for (bool fp16 : {false, true}) {
            for (uint64_t budget : {uint64_t{2}, uint64_t{16}}) {
                for (float query : {1.0F, 1000.0F}) {
                    std::vector<int64_t> ids(24);
                    for (uint64_t a = 0; a < ids.size(); ++a) {
                        ids[a] = a;
                    }
                    std::vector<float> vectors(24, 100.0F);
                    vectors[5] = -1000.0F;
                    vectors[12] = 0.9F;
                    vectors[14] = 40.0F;
                    std::vector<std::vector<uint64_t>> links(24);
                    links[5] = {12, 14};
                    std::vector<uint16_t> encoded;
                    for (float value : vectors) {
                        encoded.push_back(vsag::lite::detail::encode_fp16(value));
                    }
                    auto loaded = fp16 ? vsag::lite::detail::restore_fp16_graph_backend(
                                             1, 2, budget, ids, encoded, links)
                                       : vsag::lite::detail::restore_graph_backend(
                                             1, 2, budget, ids, vectors, links);
                    check(static_cast<bool>(loaded), "restore failed");
                    auto& graph = **loaded;
                    check(static_cast<bool>(graph.Update(5, &query, 1)), "update failed");
                    validate(graph);
                    check(graph.LinkCountAt(5) == 2, "wrong result count");
                    const bool competitive =
                        query == 1 and ((enabled and not fp16) or budget == 16);
                    check(graph.LinkAt(5, 0) == (competitive ? 12 : 0), "wrong nearest selected");
                    check(graph.LinkAt(5, 1) == (competitive ? 14 : 1), "wrong second selected");
                    check(static_cast<bool>(graph.Update(5, &query, 1)), "unchanged update failed");
                    const float bad = std::numeric_limits<float>::quiet_NaN();
                    check(not graph.Update(5, &bad, 1), "invalid update accepted");
                    check(not graph.Update(999, &query, 1), "missing id accepted");
                    check(graph.Remove(3), "remove failed");
                    validate(graph);
                    const float added = 200.0F;
                    check(static_cast<bool>(graph.Add(99, &added, 1)), "add failed");
                    validate(graph);
                }
            }
        }
        auto single = vsag::lite::detail::restore_graph_backend(1, 2, 2, {0}, {1}, {{}});
        check(static_cast<bool>(single), "single restore failed");
        const float changed = 2;
        check(
            static_cast<bool>((*single)->Update(0, &changed, 1)) and (*single)->LinkCountAt(0) == 0,
            "empty pool failed");
        validate(**single);
        std::cout << "Scored-old Update fixtures passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
