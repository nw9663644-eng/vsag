set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import difflib,hashlib,json,os,subprocess,tarfile,io
from pathlib import Path
out=Path("lite/benchmark/results/rabitq-grouped-scan-20261010")
assert len(json.loads((out/"rows.json").read_text()))==12
env=dict(os.environ,TMPDIR="/dev/shm",ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
records=[{"tag":"release-build","command":["cmake","--build","build-lite-fp16-simd-release","-j2"],"exit":0},
{"tag":"release-test","command":["ctest","--test-dir","build-lite-fp16-simd-release","-V"],"exit":0}]
assert "100% tests passed, 0 tests failed out of 6" in (out/"release-test.log").read_text()
def run(tag,command):
 with (out/(tag+".log")).open("w") as log:
  result=subprocess.run(command,env=env,stdout=log,stderr=log)
 records.append({"tag":tag,"command":command,"exit":result.returncode})
 (out/"validation-commands.json").write_text(json.dumps(records,indent=2)+"\n")
 assert result.returncode==0,tag
header=Path("src/lite/rabitq_graph_state.h");test=Path("src/lite/rabitq_backend_test.cpp")
candidate={str(p):p.read_bytes() for p in (header,test)}
(out/"candidate.patch").write_bytes(subprocess.check_output(["git","diff","--",str(header),str(test)]))
run("candidate-sanitize-build",["cmake","--build","/home/ubuntu/project/vsag-opt-sanitize-20261009","-j2"])
run("candidate-sanitize-test",["ctest","--test-dir","/home/ubuntu/project/vsag-opt-sanitize-20261009","-V"])
for p in (header,test):
 old=p.read_text()
 parent=subprocess.check_output(["git","show","194bf868b4197e0f4b60a4e7c84648dd5c5fed21:"+str(p)]).decode()
 subprocess.run(["git","apply","-"],input="".join(difflib.unified_diff(old.splitlines(True),parent.splitlines(True),fromfile="a/"+str(p),tofile="b/"+str(p))).encode(),check=True)
for tag,build in (("restored-release","build-lite-fp16-simd-release"),("restored-sanitize","/home/ubuntu/project/vsag-opt-sanitize-20261009")):
 run(tag+"-build",["cmake","--build",build,"-j2"])
 run(tag+"-test",["ctest","--test-dir",build,"-V"])
run("format",["clang-format-15","--dry-run","--Werror",str(header),str(test),"src/lite/graph_allocation_test.cpp"])
run("tidy",["clang-tidy-15","-p","build-lite-fp16-simd-release","-header-filter=.*/src/lite/.*","-warnings-as-errors=*","src/lite/rabitq_backend.cpp",str(test),"src/lite/graph_allocation_test.cpp"])
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=json.loads((out/"identity.json").read_text())
validation={"decision":"Rejected grouped scan; production restored byte-exact to parent194bf86",
"final_source_sha256":{name:sha(Path(name).read_bytes()) for name in identity["source_sha256"]},
"default_library_sha256":sha(Path("build-lite-fp16-simd-release/libvsag-lite.so").read_bytes()),
"tests":{"candidate_release":6,"candidate_asan_ubsan":5,"restored_release":6,"restored_asan_ubsan":5},
"coverage":"Inherited unchanged parent, no fresh coverage/disabled-backend suite",
"format_version":15,"tidy_version":15,"candidate_lint":"Formatted15 before timing; no separate candidate tidy claim",
"limitations":["Not Full comparison","No100k/cold I/O/quality fix","No new coverage/OFF/wholeFull/Node checker"]}
assert validation["final_source_sha256"][str(header)]==identity["control_header_sha256"]
assert subprocess.check_output(["git","diff","--",str(header),str(test),"src/lite/rabitq_backend.cpp"])==b""
(out/"validation.json").write_text(json.dumps(validation,indent=2)+"\n")
with tarfile.open(out/"raw.tar.gz") as t:raw={m.name.removeprefix("./"):t.extractfile(m).read() for m in t if m.isfile()}
raw["final-state.h"]=header.read_bytes();raw["final-test.cpp"]=test.read_bytes()
raw["official-quantizer.cpp"]=Path("src/quantization/rabitq_quantization/rabitq_quantizer.cpp").read_bytes()
for p in out.glob("*.log"):raw[p.name]=p.read_bytes()
for n in ("validation.json","validation-commands.json","candidate.patch"):raw[n]=(out/n).read_bytes()
with tarfile.open(out/"raw.tar.gz","w:gz") as t:
 for name,blob in sorted(raw.items()):
  info=tarfile.TarInfo("./"+name);info.size=len(blob);t.addfile(info,io.BytesIO(blob))
(out/"members.json").write_text(json.dumps({name:sha(blob) for name,blob in sorted(raw.items())},indent=2)+"\n")
print("Candidate rejected; final source/default lib restored",validation["default_library_sha256"],flush=True)
PY
