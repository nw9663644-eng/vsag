set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import hashlib,json,subprocess,shlex
from pathlib import Path
out=Path("lite/benchmark/results/rabitq-grouped-scan-20261010");assert len(json.loads((out/"rows.json").read_text()))==12
repo=Path.cwd().resolve();base=(repo/"build-full-comparison-library").resolve()
target=(base/"src/libvsag_static.a").resolve()
assert target.is_relative_to(base) and base.is_relative_to(repo) and target.is_file()
assert target.stat().st_size==1301968226
processes=subprocess.check_output(["ps","-eo","pid,args"]).decode()
assert str(base) not in processes and not any(x in processes for x in ("cmake --build","cc1plus","ctest","lite_graph_crud_quality"))
cache=(base/"CMakeCache.txt").read_text();assert "CMAKE_HOME_DIRECTORY:INTERNAL="+str(repo) in cache
line=next(s for s in (base/"build.ninja").read_text().splitlines() if s.startswith("build src/libvsag_static.a:"))
objects=[base/x for x in line.split() if x.endswith(".o")]
assert len(objects)>100
commands=subprocess.check_output(["ninja","-C",str(base),"-t","commands","vsag_static"]).decode().splitlines()
mapping={}
for command in commands:
 args=shlex.split(command)
 if "-c" not in args or "-o" not in args:continue
 obj=args[args.index("-o")+1];source=Path(args[args.index("-c")+1])
 includes=[Path(x[2:]) for x in args if x.startswith("-I") and len(x)>2]
 includes += [Path(args[i+1]) for i,x in enumerate(args[:-1]) if x=="-isystem"]
 assert source.is_file() and all((x if x.is_absolute() else base/x).is_dir() for x in includes)
 assert Path(args[0]).is_file()
 mapping[obj]={"source":str(source),"command":command}
recipes={str(p.relative_to(base)):mapping[str(p.relative_to(base))] for p in objects}
assert len(recipes)==219
for p in (repo/"CMakeLists.txt",repo/"src/CMakeLists.txt",base/"src/libvsag.so.0.0.0"):assert p.is_file()
# No process currently holds the target open; don't infer this solely from command names.
for folder in Path("/proc").iterdir():
 if not folder.name.isdigit():continue
 try:
  for fd in (folder/"fd").iterdir():
   try:assert str(fd.readlink())!=str(target)
   except (PermissionError,FileNotFoundError):pass
 except (PermissionError,FileNotFoundError):pass
h=hashlib.sha256()
with target.open("rb") as f:
 while chunk:=f.read(1024*1024):h.update(chunk)
record={"path":str(target),"bytes":target.stat().st_size,"sha256":h.hexdigest(),"manifest":line,
"object_files_already_absent":sum(not p.is_file() for p in objects),"verified_rebuild_recipes":recipes,"shared_library_preserved":str(base/"src/libvsag.so.0.0.0"),
"rebuild":"cmake --build "+str(base)+" --target vsag_static",
"reason":"Verified inactive reconstructible static archive only, no source/data/raw/shared library deletion"}
(out/"cleanup.json").write_text(json.dumps(record,indent=2)+"\n")
target.unlink()
print("Removed verified inactive/rebuildable static archive",record["bytes"],"bytes; objects",len(objects),flush=True)
PY
