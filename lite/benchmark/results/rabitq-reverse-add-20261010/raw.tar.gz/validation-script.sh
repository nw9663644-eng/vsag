set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import json,os,subprocess
from pathlib import Path
out=Path("lite/benchmark/results/rabitq-reverse-add-20261010")
logs=Path("/home/ubuntu/project/vsag-lite-reverse-add-20261010")
assert len(json.loads((out/"rows.json").read_text()))==12
records=[{"tag":"release-build","command":["cmake","--build","build-lite-fp16-simd-release","-j2"],"exit":0},
 {"tag":"release-test","command":["ctest","--test-dir","build-lite-fp16-simd-release","-V"],"exit":0}]
assert "100% tests passed, 0 tests failed out of 6" in (logs/"release-test.log").read_text()
env=dict(os.environ,TMPDIR="/dev/shm",ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
def run(tag,cmd):
 with (logs/(tag+".log")).open("w") as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=log)
 records.append({"tag":tag,"command":cmd,"exit":r.returncode})
 (out/"validation-commands.json").write_text(json.dumps(records,indent=2)+"\n")
 assert r.returncode==0,tag
for tag,build in (("sanitize-final","/home/ubuntu/project/vsag-opt-sanitize-20261009"),
 ("coverage","/home/ubuntu/project/vsag-opt-coverage-20261009"),("default","/home/ubuntu/project/vsag-opt-default-20261009")):
 run(tag+"-build",["cmake","--build",build,"-j2"])
 if tag=="coverage":
  base=Path(build).resolve();files=list(base.rglob("*.gcda"));assert len(files)==19
  for p in files:
   assert p.resolve().is_relative_to(base) and p.is_file()
   p.unlink()
  print("Reset19 verified generated coverage counters",flush=True)
 run(tag+"-test",["ctest","--test-dir",build,"-V"])
run("format-final",["clang-format-15","--dry-run","--Werror","src/lite/rabitq_graph_state.h","src/lite/graph_allocation_test.cpp"])
run("tidy-final",["clang-tidy-15","-p","build-lite-fp16-simd-release","-header-filter=.*/src/lite/.*","-warnings-as-errors=*","src/lite/rabitq_backend.cpp","src/lite/graph_allocation_test.cpp"])
print("Final validation complete",flush=True)
PY
