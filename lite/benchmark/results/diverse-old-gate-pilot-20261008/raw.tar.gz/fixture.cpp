// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include <algorithm>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <vector>

#include "lite/backend.h"
#include "lite/fp16_codec.h"

void
check(bool ok, const char* reason) {
    if (not ok)
        throw std::runtime_error(reason);
}
void
validate(const vsag::lite::detail::Backend& graph) {
    std::vector<std::vector<uint64_t>> incoming(graph.Size());
    for (uint64_t a = 0; a < graph.Size(); ++a) {
        check(graph.LinkCountAt(a) <= 2, "degree exceeded");
        std::unordered_set<uint64_t> unique;
        for (uint64_t r = 0; r < graph.LinkCountAt(a); ++r) {
            const auto b = graph.LinkAt(a, r);
            check(b < graph.Size() && b != a && unique.insert(b).second, "bad edge");
            incoming[b].push_back(a);
        }
    }
    for (uint64_t b = 0; b < graph.Size(); ++b) {
        std::vector<uint64_t> actual;
        for (uint64_t r = 0; r < graph.IncomingLinkCountAt(b); ++r)
            actual.push_back(graph.IncomingLinkAt(b, r));
        std::sort(actual.begin(), actual.end());
        std::sort(incoming[b].begin(), incoming[b].end());
        check(actual == incoming[b], "incoming mismatch");
    }
}
std::vector<uint64_t>
run(bool fp16, bool diverse_case) {
    std::vector<int64_t> ids(24);
    for (uint64_t i = 0; i < 24; ++i) ids[i] = i;
    std::vector<float> vectors(48, 100.0F);
    auto put = [&](uint64_t s, float x, float y) {
        vectors[s * 2] = x;
        vectors[s * 2 + 1] = y;
    };
    put(0, 1, 0);
    put(1, 0, 1);
    put(5, -1000, -1000);
    put(12, .9F, 0);
    put(14, diverse_case ? -.8F : 0, diverse_case ? 0 : .9F);
    std::vector<std::vector<uint64_t>> links(24);
    links[5] = {12, 14};
    std::vector<uint16_t> encoded;
    for (float v : vectors) encoded.push_back(vsag::lite::detail::encode_fp16(v));
    auto loaded = fp16
                      ? vsag::lite::detail::restore_fp16_graph_backend(2, 2, 2, ids, encoded, links)
                      : vsag::lite::detail::restore_graph_backend(2, 2, 2, ids, vectors, links);
    check(bool(loaded), "restore failed");
    const float q[2] = {0, 0};
    check(bool((*loaded)->Update(5, q, 2)), "update failed");
    validate(**loaded);
    std::vector<uint64_t> result;
    for (uint64_t r = 0; r < (*loaded)->LinkCountAt(5); ++r)
        result.push_back((*loaded)->LinkAt(5, r));
    return result;
}
int
main(int argc, char** argv) {
    try {
        check(argc == 2, "expected on/off");
        const bool on = std::string(argv[1]) == "on";
        auto diverse = run(false, true);
        check(diverse.size() == 2, "wrong size");
        check(std::find(diverse.begin(), diverse.end(), 12) == diverse.end(),
              "occluded old candidate retained");
        check((std::find(diverse.begin(), diverse.end(), 14) != diverse.end()) == on,
              "diverse candidate gate mismatch");
        auto occluded = run(false, false);
        check(std::find(occluded.begin(), occluded.end(), 12) == occluded.end(),
              "first occluded retained");
        check(std::find(occluded.begin(), occluded.end(), 14) == occluded.end(),
              "second occluded retained");
        auto fp16 = run(true, true);
        check(std::find(fp16.begin(), fp16.end(), 14) == fp16.end(), "FP16 changed");
        std::cout << "Diverse-old gate fixtures passed\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
