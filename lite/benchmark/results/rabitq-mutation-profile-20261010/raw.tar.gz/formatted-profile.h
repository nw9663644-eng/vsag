// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <array>
#include <chrono>
#include <cstdio>
#include <ctime>
namespace vsag::lite::detail::rabitq::diagnostic {
enum Stage {
  ADAPTER,
  NEAREST,
  DECODE,
  LINK,
  REPAIR,
  SCORE,
  SCAN,
  ENCODE,
  STAGES
};
inline const char *names[] = {
    "adapter",      "nearest",        "decode",        "link_other",
    "repair_other", "score_and_sort", "incoming_scan", "prepare_encoding"};
inline const char *ops[] = {"add", "update", "remove"};
inline int operation = -1;
inline double cpu_us() {
  timespec ts{};
  clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &ts);
  return ts.tv_sec * 1e6 + ts.tv_nsec / 1e3;
}
inline double wall_us() {
  return std::chrono::duration<double, std::micro>(
             std::chrono::steady_clock::now().time_since_epoch())
      .count();
}
struct Value {
  unsigned long long calls{};
  double cpu{}, wall{}, inclusive_cpu{};
};
struct Stats {
  std::array<std::array<Value, STAGES>, 3> values{};
  ~Stats() {
    std::fprintf(stderr, "\nPROFILE_BEGIN\nop,stage,calls,cpu_exclusive_us,"
                         "wall_exclusive_us,cpu_inclusive_us\n");
    for (int op = 0; op < 3; ++op) {
      for (int stage = 0; stage < STAGES; ++stage) {
        const auto &v = values[op][stage];
        std::fprintf(stderr, "%s,%s,%llu,%.6f,%.6f,%.6f\n", ops[op],
                     names[stage], v.calls, v.cpu, v.wall, v.inclusive_cpu);
      }
    }
    std::fprintf(stderr, "PROFILE_END\n");
  }
};
inline Stats stats;
struct Scope;
inline Scope *current{};
struct Scope {
  Stage stage;
  int op;
  Scope *parent{};
  double cpu{}, wall{}, child_cpu{}, child_wall{};
  bool done{};
  explicit Scope(Stage s) : stage(s), op(operation) {
    if (op < 0)
      return;
    parent = current;
    current = this;
    wall = wall_us();
    cpu = cpu_us();
  }
  void Finish() {
    if (done || op < 0)
      return;
    const double elapsed_cpu = cpu_us() - cpu;
    const double elapsed_wall = wall_us() - wall;
    auto &v = stats.values[op][stage];
    ++v.calls;
    v.cpu += elapsed_cpu - child_cpu;
    v.wall += elapsed_wall - child_wall;
    v.inclusive_cpu += elapsed_cpu;
    if (parent) {
      parent->child_cpu += elapsed_cpu;
      parent->child_wall += elapsed_wall;
    }
    current = parent;
    done = true;
  }
  ~Scope() { Finish(); }
};
struct Operation {
  int old;
  Scope scope;
  explicit Operation(int op) : old(operation), scope(Set(op)) {}
  static Stage Set(int op) {
    operation = op;
    return ADAPTER;
  }
  ~Operation() {
    scope.Finish();
    operation = old;
  }
};
} // namespace vsag::lite::detail::rabitq::diagnostic
