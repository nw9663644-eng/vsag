// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#include "mutation-profile.h"
#include <cassert>
#include <cstdio>
#include <stdexcept>
using namespace vsag::lite::detail::rabitq::diagnostic;
int main() {
  double sum = 0;
  double wall = wall_us();
  for (int i = 0; i < 100000; ++i) {
    sum += cpu_us();
  }
  std::printf("clock_reads,elapsed_wall_us,sum\n100000,%.6f,%.6f\n",
              wall_us() - wall, sum);
  {
    Operation op(0);
    for (int i = 0; i < 100000; ++i) {
      Scope inner(DECODE);
    }
  }
  try {
    Operation op(1);
    Scope parent(NEAREST);
    Scope child(SCORE);
    throw std::runtime_error("scope unwind fixture");
  } catch (const std::runtime_error &) {
  }
  assert(operation == -1 && current == nullptr);
  assert(stats.values[0][ADAPTER].calls == 1);
  assert(stats.values[0][DECODE].calls == 100000);
  assert(stats.values[1][ADAPTER].calls == 1);
  assert(stats.values[1][NEAREST].calls == 1);
  assert(stats.values[1][SCORE].calls == 1);
}
