// Copyright 2024-present the vsag project
// SPDX-License-Identifier: Apache-2.0
#pragma once

#include <cstdint>
#include <queue>
#include <vector>

namespace vsag::lite::detail {

// Query-local bounded result heap. Compare and tie ordering match priority_queue.
// Callers keep capacity fixed and insert only through PushBounded.
template <typename T, typename Compare>
class BoundedHeap : public std::priority_queue<T, std::vector<T>, Compare> {
    using Base = std::priority_queue<T, std::vector<T>, Compare>;

public:
    using Base::Base;

    bool
    PushBounded(const T& value, uint64_t capacity) {
        if (capacity == 0) {
            return false;
        }
        if (this->size() < capacity) {
            this->push(value);
            return true;
        }
        if (not this->comp(value, this->c.front())) {
            return false;
        }
        // Like native StandardHeap, reject before writing a full result heap.
        // Replace its worst element with one sift-down instead of push plus pop.
        const T replacement = value;
        const uint64_t count = this->c.size();
        uint64_t parent = 0;
        while (parent < count / 2) {
            uint64_t child = parent * 2 + 1;
            if (child + 1 < count and this->comp(this->c[child], this->c[child + 1])) {
                ++child;
            }
            if (not this->comp(replacement, this->c[child])) {
                break;
            }
            this->c[parent] = this->c[child];
            parent = child;
        }
        this->c[parent] = replacement;
        return true;
    }
};

}  // namespace vsag::lite::detail
