set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import csv,difflib,gzip,hashlib,importlib.util,io,json,statistics,subprocess,tarfile,tempfile
from pathlib import Path
VALIDATION_SCRIPT=json.loads("\"set -eu\\ncd /home/ubuntu/project/vsag-lite-baseline-v01\\npython3 - <<'PY'\\nimport json,os,subprocess\\nfrom pathlib import Path\\nout=Path(\\\"lite/benchmark/results/rabitq-reverse-update-20261010\\\")\\nlogs=Path(\\\"/home/ubuntu/project/vsag-lite-reverse-update-20261010\\\")\\nassert len(json.loads((out/\\\"rows.json\\\").read_text()))==12\\nrecords=[{\\\"tag\\\":\\\"release-build\\\",\\\"command\\\":[\\\"cmake\\\",\\\"--build\\\",\\\"build-lite-fp16-simd-release\\\",\\\"-j2\\\"],\\\"exit\\\":0},\\n {\\\"tag\\\":\\\"release-test\\\",\\\"command\\\":[\\\"ctest\\\",\\\"--test-dir\\\",\\\"build-lite-fp16-simd-release\\\",\\\"-V\\\"],\\\"exit\\\":0}]\\nassert \\\"100% tests passed, 0 tests failed out of 6\\\" in (logs/\\\"release-fixed-test.log\\\").read_text()\\nenv=dict(os.environ,TMPDIR=\\\"/dev/shm\\\",ASAN_OPTIONS=\\\"detect_leaks=1:halt_on_error=1\\\",UBSAN_OPTIONS=\\\"halt_on_error=1:print_stacktrace=1\\\")\\ndef run(tag,cmd):\\n with (logs/(tag+\\\".log\\\")).open(\\\"w\\\") as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=log)\\n records.append({\\\"tag\\\":tag,\\\"command\\\":cmd,\\\"exit\\\":r.returncode})\\n (out/\\\"validation-commands.json\\\").write_text(json.dumps(records,indent=2)+\\\"\\\\n\\\")\\n assert r.returncode==0,tag\\nfor tag,build in ((\\\"sanitize-fixed\\\",\\\"/home/ubuntu/project/vsag-opt-sanitize-20261009\\\"),\\n (\\\"coverage\\\",\\\"/home/ubuntu/project/vsag-opt-coverage-20261009\\\"),(\\\"default\\\",\\\"/home/ubuntu/project/vsag-opt-default-20261009\\\")):\\n run(tag+\\\"-build\\\",[\\\"cmake\\\",\\\"--build\\\",build,\\\"-j2\\\"])\\n if tag==\\\"coverage\\\":\\n  base=Path(build).resolve();files=list(base.rglob(\\\"*.gcda\\\"));assert len(files)==19\\n  for p in files:\\n   assert p.resolve().is_relative_to(base) and p.is_file()\\n   p.unlink()\\n  print(\\\"Reset19 verified generated coverage counters\\\",flush=True)\\n run(tag+\\\"-test\\\",[\\\"ctest\\\",\\\"--test-dir\\\",build,\\\"-V\\\"])\\nrun(\\\"format-final\\\",[\\\"clang-format-15\\\",\\\"--dry-run\\\",\\\"--Werror\\\",\\\"src/lite/rabitq_graph_state.h\\\",\\\"src/lite/graph_allocation_test.cpp\\\"])\\nrun(\\\"tidy-final\\\",[\\\"clang-tidy-15\\\",\\\"-p\\\",\\\"build-lite-fp16-simd-release\\\",\\\"-header-filter=.*/src/lite/.*\\\",\\\"-warnings-as-errors=*\\\",\\\"src/lite/rabitq_backend.cpp\\\",\\\"src/lite/graph_allocation_test.cpp\\\"])\\nprint(\\\"Final validation complete\\\",flush=True)\\nPY\\n\"")
out=Path("lite/benchmark/results/rabitq-reverse-update-20261010");repo=Path.cwd()
logs=Path("/home/ubuntu/project/vsag-lite-reverse-update-20261010")
sha=lambda b:hashlib.sha256(b).hexdigest()
def setfile(p,new):
 old=p.read_text() if p.exists() else ""
 if old==new:return
 diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
  fromfile='a/'+str(p) if p.exists() else '/dev/null',tofile='b/'+str(p)))
 subprocess.run(['git','apply','-'],input=diff,text=True,check=True)
commands=json.loads((out/"validation-commands.json").read_text())
assert len(commands)==10 and all(x["exit"]==0 for x in commands)
with tarfile.open(out/"raw.tar.gz") as t:raw={m.name.removeprefix("./"):t.extractfile(m).read() for m in t if m.isfile()}
rows=json.loads((out/"rows.json").read_text());assert len(rows)==12
paired={};comparison={}
for label in ("gist10k600","cohere10k600"):
 for repeat in range(3):
  paired[label+"-r"+str(repeat)]={"extra_hits":0,"wins":0,"losses":0,"ties":600,"mean_recall_delta":0.0}
 groups=[[r for r in rows if r["dataset"]==label and r["variant"]==v] for v in ("control","candidate")]
 first,second=[[float(r["result"]["crud_ms"]) for r in sorted(group,key=lambda r:r["repeat"])] for group in groups]
 comparison[label]={"control_crud_ms":first,"candidate_crud_ms":second,"control_median_ms":statistics.median(first),
 "candidate_median_ms":statistics.median(second),"median_change_percent":(statistics.median(second)/statistics.median(first)-1)*100,
 "paired_changes_percent":[(b/a-1)*100 for a,b in zip(first,second)],"snapshot_and_ordered_results_identical":True}
for n,obj in (("paired.json",paired),("comparison.json",comparison)):
 (out/n).write_text(json.dumps(obj,indent=2)+"\n")
cov=Path("/home/ubuntu/project/vsag-opt-coverage-20261009");ram=Path(tempfile.mkdtemp(prefix="vsag-reverse-update-gcov-",dir="/dev/shm"))
files=list(cov.rglob("*.gcda"));assert len(files)==19
with (out/"gcov.log").open("w") as log:
 for p in files:subprocess.run(["gcov","--json-format",str(p)],cwd=ram,stdout=log,stderr=log,check=True)
lines={};gz=sorted(ram.glob("*.gcov.json.gz"));assert len(gz)==19
for p in gz:
 obj=json.loads(gzip.decompress(p.read_bytes()))
 for f in obj["files"]:
  for l in f["lines"]:
   key=(str(Path(f["file"])),l["line_number"]);lines[key]=lines.get(key,False) or l["count"]>0
scopes={}
for scope in ("lite","shared_simd","combined"):
 vals=[]
 for (name,num),covered in lines.items():
  lite=("/src/lite/" in name or "/include/vsag/lite/" in name) and not name.endswith("_test.cpp")
  simd="/src/simd/" in name and not name.endswith("_test.cpp")
  if (scope=="lite" and lite) or (scope=="shared_simd" and simd) or (scope=="combined" and (lite or simd)):vals.append(covered)
 scopes[scope]={"covered":sum(vals),"total":len(vals),"percent":sum(vals)*100/len(vals)}
 assert scopes[scope]["percent"]>=90
(out/"coverage.json").write_text(json.dumps({"scopes":scopes,"fresh_counters":True,
 "scope_note":"Compiled Lite production/public headers and instantiated shared SIMD, not whole Full coverage."},indent=2)+"\n")
with tarfile.open(out/"coverage-raw.tar.gz","w:gz") as t:
 for p in gz:t.add(p,arcname=p.name)
identity=json.loads((out/"identity.json").read_text())
final={n:sha((repo/n).read_bytes()) for n in identity["source_sha256"]}
assert final==identity["source_sha256"]
validation={"decision":"Retain reverse Update local journal; internal reverse remains disabled by default",
 "final_source_sha256":final,"default_library_sha256":sha((repo/"build-lite-fp16-simd-release/libvsag-lite.so").read_bytes()),
 "tests":{"release":6,"asan_ubsan":5,"fresh_coverage":5,"rabitq_disabled":4},"format_version":15,"tidy_version":15,
 "limits":["Not public-default speedup","Add/Remove retain full-copy reverse fallback","Cold cached Update retains full-copy fallback",
 "Not Full comparison","No100k/cold I/O/quality fix/wholeFull/Node checker"]}
(out/"validation.json").write_text(json.dumps(validation,indent=2)+"\n")
(out/"candidate.patch").write_bytes(subprocess.check_output(["git","diff","--","src/lite/rabitq_graph_state.h","src/lite/graph_allocation_test.cpp","lite/CMakeLists.txt"]))
for p in logs.glob("*.log"):raw[p.name]=p.read_bytes()
raw["gcov.log"]=(out/"gcov.log").read_bytes()
for n in ("validation.json","validation-commands.json","coverage.json","candidate.patch"):raw[n]=(out/n).read_bytes()
raw["final-state.h"]=(repo/"src/lite/rabitq_graph_state.h").read_bytes()
raw["final-allocation-test.cpp"]=(repo/"src/lite/graph_allocation_test.cpp").read_bytes()
raw["lite-CMakeLists.txt"]=(repo/"lite/CMakeLists.txt").read_bytes()
for src,name in (("src/simd/kernels/rabitq_compute.h","official-rabitq-kernels.h"),
 ("src/lite/rabitq_filter_ip.cpp","dispatch.cpp"),("src/lite/rabitq_filter_ip_avx2.cpp","avx2-wrapper.cpp"),
 ("src/lite/rabitq_filter_ip_avx512.cpp","avx512-wrapper.cpp")):raw[name]=(repo/src).read_bytes()
raw["validation-script.sh"]=VALIDATION_SCRIPT.encode()
raw["collection-script.sh"]=(out/"collect-run.sh").read_bytes()
with tarfile.open(out/"raw.tar.gz","w:gz") as t:
 for name,blob in sorted(raw.items()):
  m=tarfile.TarInfo("./"+name);m.size=len(blob);t.addfile(m,io.BytesIO(blob))
(out/"members.json").write_text(json.dumps({n:sha(b) for n,b in sorted(raw.items())},indent=2)+"\n")
# Final replay pins the measured source, not the possibly changed future checkout.
p=out/"run-host.py";old=p.read_text()
new=old.replace('    shutil.copyfile(repo / source_names[0], raw / "candidate-state.h")',
'''    with tarfile.open(repo / "lite/benchmark/results/rabitq-reverse-update-20261010/raw.tar.gz") as archive:
        (raw / "candidate-state.h").write_bytes(archive.extractfile("./candidate-state.h").read())
    identity["source_sha256"][source_names[0]] = digest(raw / "candidate-state.h")
    assert identity["source_sha256"][source_names[3]] == "TOOL_SHA"
    assert identity["source_sha256"][source_names[4]] == "PREP_SHA"''')
new=new.replace("TOOL_SHA",identity["source_sha256"]["lite/benchmark/graph_crud_quality.cpp"]).replace("PREP_SHA",identity["source_sha256"]["lite/benchmark/prepare_persistent_crud.py"])
assert new!=old
setfile(p,new)
compile(new,str(p),"exec")
table=["| Dataset | Full-copy Update block (ms) | Local journal (ms) | Change |",
 "|---|---:|---:|---:|"]
for label,c in comparison.items():
 table.append("| "+label+" | %.3f | %.3f | %+.2f%% |"%(c["control_median_ms"],c["candidate_median_ms"],c["median_change_percent"]))
readme="""# Reverse RaBitQ Update local transaction journal (2026-10-10)

This optimizes an existing **internal reverse-adjacency path**, not the public default.
Control is production parent77b8543 with whole-state copy transactions; candidate journals only
the replaced encoding and affected outgoing/incoming rows. Both measured overlays enable
incoming adjacency by the identical one-token constructor-default transform (false to true),
recorded and independently checked. Both use NONE protection. Public constructor default stays
false, Add/Remove retain their reverse full-copy fallback, and the first cold CACHED Update
retains copy isolation for the count-array rebuild.

Source evidence: MutableGraphState::UpdateTransactional copied all model/codes/IDs/maps/edges
on reverse updates; UpdatePrepared already localized sources using incoming_[slot]. Existing
remember_row and snapshot/Validate fixtures supply the outgoing rollback approach. Native
RaBitQ Batch4/filter/supplement dispatch and all scoring/formulas/order/model/budgets/API/snapshot
format are unchanged. Reverse rows are saved before count deltas or edge mutations; failure
restores rows by swaps and valid counts from restored incoming cardinalities, without allocating.
The known memory totals now include reverse vector payload/capacity, previously reported only
separately; these totals are not allocator-inclusive RSS or transient journal memory.

## Fixed-budget paired measurements

10k GIST960/Cohere768,600 preserved queries,k10,degree16,maintenance ef128,query ef512,CPU0,
one thread,three full-ID passes of true changed whole-vector Update only (30000 updates/builder).
Three alternating-order pairs per dataset,12 fresh builders. No Remove/Add operations were
timed here; no claim of public-default,query,Full or generic speedup.

TABLE

All six pairs show lower Update-block duration in this sample, not a statistical/universal
claim. Each block includes operation timing/loop overhead. summary.json independently derives
per-operation P50/P99 and throughput; rows.json preserves build/load/save/query and external
process-peak RSS. RSS includes input matrices/build/query/load and is not a mutation-only peak.
Both variants retain ordered IDs/hex distances/hits, initial/final query CSV and snapshot SHA
exactly; native Save/Load exact check runs inside each builder. Final Recall@10 remains GIST
0.858667 and Cohere0.935500 for this Update-only workload, below research floors0.90/0.95.
Do not compare these with mixed CRUD .811167/.908167 as an optimization-induced quality gain.

## Validation and replay

Release6/6,ASan/UBSan5/5,fresh scoped coverage5/5,RaBitQ-disabled4/4,format15/tidy15 passed.
New internal failure injection covers500 positions each for NONE,RECOUNT,CACHED cold and warm:
347 observed allocation failures,zero state/rebuild/retry mismatches,plus successful mutations.
Existing public fixture covers another6000 positions. An initial test-only exception-escape lint
failure was fixed by catching fixture setup/validation failures at main; original log retained,
all final validation rerun. No production change after timing. COVERAGE

python3 lite/benchmark/results/rabitq-reverse-update-20261010/verify.py
audits360000 Update rows,14400 truth intersections,quantiles,throughput,paired exact results,
dependency/header bindings,validation exits,fresh coverage union and all hashes without rerunning
experiments. raw.tar.gz preserves actual measured runner,original/compiled headers,patch,adapter
compile/link commands,LD bindings,source receipts,query/truth/latencies and validation logs.
run-host.py is syntax-checked only after pinning archived candidate; replays require retained
dataset/source/build dependencies,output helper copy and compatible native AVX configuration.
Large replacements are reproducibly generated from retained base and recipe; only new RAM
snapshots were removed after exact load and SHA receipts. No old source/data/raw/binaries deleted.

100k,true interleaved CRUD,reverse Add/Remove local journals,public-path memory/time decision,
fresh native Full aligned configuration/SIMD/quality,cold-I/O and complete deployment package
acceptance remain open. PR2904/2926 are not updated.

## Boundary summary

This is an internal-path structural optimization; public defaults and project acceptance remain
unchanged. See the Chinese design note for rollback,cache and memory boundaries.
"""
readme=readme.replace("TABLE","\n".join(table)).replace("COVERAGE",
 "Scoped Lite coverage%d/%d=%.2f%%;not whole Full coverage."%(scopes["lite"]["covered"],scopes["lite"]["total"],scopes["lite"]["percent"]))
setfile(out/"README.md",readme)
names=["README.md","verify.py","run-host.py","raw.tar.gz","members.json","identity.json","rows.json","summary.json",
 "paired.json","comparison.json","validation.json","validation-commands.json","coverage.json","coverage-raw.tar.gz"]
def hashes(): (out/"SHA256SUMS").write_text(''.join(sha((out/n).read_bytes())+"  "+n+"\n" for n in names if (out/n).exists()))
hashes()
spec=importlib.util.spec_from_file_location("audit",out/"verify.py");module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
summary=module.audit(out)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
hashes()
subprocess.run(["python3",str(out/"verify.py")],check=True)
print(json.dumps({"comparison":comparison,"coverage":scopes,"raw_members":len(raw),"raw_bytes":sum(map(len,raw.values()))},indent=2))
PY
