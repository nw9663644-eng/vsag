set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
from pathlib import Path
import subprocess,difflib,os,json
out=Path('lite/benchmark/results/rabitq-link-scratch-20261010')
header=Path('src/lite/rabitq_graph_state.h')
measured_header=header.read_text()
parent_header=subprocess.check_output(['git','show','cd8e91edfefd7c57c8aee870a7efe14a22dedcf1:'+str(header)]).decode()
(out/'candidate.patch').write_text(''.join(difflib.unified_diff(parent_header.splitlines(True),measured_header.splitlines(True),fromfile='a/'+str(header),tofile='b/'+str(header))))
adapter=Path('src/lite/rabitq_backend.cpp'); original=adapter.read_text()
needle='explicit RaBitQBackend(rabitq::MutableGraphState state) : state_(std::move(state)) {\n'
assert original.count(needle)==1
candidate=original.replace(needle,needle+'        state_.ConfigureIncomingProtection(rabitq::IncomingProtection::CACHED, true, true, true);\n',1)
def change(first,second):
 patch=''.join(difflib.unified_diff(first.splitlines(True),second.splitlines(True),fromfile='a/'+str(adapter),tofile='b/'+str(adapter)))
 subprocess.run(['git','apply','-'],input=patch.encode(),check=True)
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
records=[]
def run(tag,command):
 with (out/(tag+'.log')).open('w') as log:
  result=subprocess.run(command,env=env,stdout=log,stderr=log)
 records.append({'tag':tag,'command':command,'exit':result.returncode})
 (out/'validation-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==0,tag
change(original,candidate)
try:
 run('cached-sanitize-build',['cmake','--build','/home/ubuntu/project/vsag-opt-sanitize-20261009','-j2'])
 run('cached-sanitize-test',['ctest','--test-dir','/home/ubuntu/project/vsag-opt-sanitize-20261009','-V'])
finally:
 change(candidate,original)
 assert header.read_text()==measured_header
 patch=''.join(difflib.unified_diff(measured_header.splitlines(True),parent_header.splitlines(True),fromfile='a/'+str(header),tofile='b/'+str(header)))
 subprocess.run(['git','apply','-'],input=patch.encode(),check=True)
run('final-release-build',['cmake','--build','build-lite-fp16-simd-release','-j2'])
run('final-release-test',['ctest','--test-dir','build-lite-fp16-simd-release','-V'])
for tag,build in [('sanitize','/home/ubuntu/project/vsag-opt-sanitize-20261009'),('coverage','/home/ubuntu/project/vsag-opt-coverage-20261009'),('default','/home/ubuntu/project/vsag-opt-default-20261009')]:
 run(tag+'-build',['cmake','--build',build,'-j2'])
 if tag=='coverage':
  base=Path(build).resolve(); files=list(base.rglob('*.gcda')); assert len(files)==19
  for p in files:
   assert p.resolve().is_relative_to(base);p.unlink()
  print('Removed19 generated coverage counters for fresh collection',flush=True)
 run(tag+'-test',['ctest','--test-dir',build,'-V'])
run('format',['clang-format-15','--dry-run','--Werror','src/lite/rabitq_graph_state.h','src/lite/rabitq_backend_test.cpp','src/lite/graph_allocation_test.cpp'])
run('tidy',['clang-tidy-15','-p','build-lite-fp16-simd-release','-header-filter=.*/src/lite/.*','-warnings-as-errors=*','src/lite/rabitq_backend.cpp','src/lite/rabitq_backend_test.cpp','src/lite/graph_allocation_test.cpp'])
print('Cached/default SAN, fresh Cov, OFF, format and tidy passed',flush=True)
PY