set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import difflib,subprocess
from pathlib import Path
out=Path("lite/benchmark/results/rabitq-maintenance-batch4-20261010")
(out/"pre-lint.patch").write_bytes(subprocess.check_output(["git","diff","--","src/lite/rabitq_graph_state.h","src/lite/rabitq_backend_test.cpp"]))
for p in list(out.glob("*.log"))+[out/"validation-commands.json"]:
 (out/("pre-lint-"+p.name)).write_bytes(p.read_bytes())
p=Path("src/lite/rabitq_backend_test.cpp");old=p.read_text()
a="                REQUIRE(std::memcmp(&batch[i].distance, &scalar[i].distance, sizeof(float)) == 0);"
b="""                REQUIRE(std::memcmp(reinterpret_cast<const unsigned char*>(&batch[i].distance),
                                    reinterpret_cast<const unsigned char*>(&scalar[i].distance),
                                    sizeof(float)) == 0);"""
assert old.count(a)==1
new=old.replace(a,b)
subprocess.run(["git","apply","-"],input="".join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="a/"+str(p),tofile="b/"+str(p))).encode(),check=True)
PY
clang-format-15 -i src/lite/rabitq_backend_test.cpp
TMPDIR=/dev/shm cmake --build build-lite-fp16-simd-release -j2 > lite/benchmark/results/rabitq-maintenance-batch4-20261010/release-build.log 2>&1
ctest --test-dir build-lite-fp16-simd-release -V > lite/benchmark/results/rabitq-maintenance-batch4-20261010/release-test.log 2>&1
