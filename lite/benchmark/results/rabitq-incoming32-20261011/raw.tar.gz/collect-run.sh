set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import difflib,gzip,hashlib,importlib.util,io,json,statistics,subprocess,tarfile,tempfile
from pathlib import Path
root=Path.cwd();out=root/'lite/benchmark/results/rabitq-incoming32-20261011';logs=Path('/home/ubuntu/project/vsag-incoming32-20261011')
sha=lambda b:hashlib.sha256(b).hexdigest()
def edit(p,text):
 old=p.read_text() if p.exists() else ''
 if old==text:return
 name=str(p.relative_to(root))
 subprocess.run(['git','apply','-'],input=''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/'+name if p.exists() else '/dev/null',tofile='b/'+name)),text=True,check=True)
identity=json.loads((out/'identity.json').read_text())
assert identity['base_head']=='5d633c9514c039a8134539a881b064afa62a90a0'
assert len(json.loads((out/'rows.json').read_text()))==12
assert all(sha((root/n).read_bytes())==v for n,v in identity['source_sha256'].items())
assert sha((root/'build-lite-fp16-simd-release/libvsag-lite.so').read_bytes())==identity['default_library_sha256']
commands=json.loads((out/'validation-commands.json').read_text());assert len(commands)==10 and all(r['exit']==0 for r in commands)
base=Path('/home/ubuntu/project/vsag-opt-coverage-20261009');files=list(base.rglob('*.gcda'));assert len(files)==19
ram=Path(tempfile.mkdtemp(prefix='vsag-incoming32-gcov-',dir='/dev/shm'))
with (logs/'gcov.log').open('w') as log:
 for f in files:subprocess.run(['gcov','--json-format',str(f)],cwd=ram,stdout=log,stderr=log,check=True)
gz=sorted(ram.glob('*.gcov.json.gz'));assert len(gz)==19
lines={}
for p in gz:
 for f in json.loads(gzip.decompress(p.read_bytes()))['files']:
  for l in f['lines']:
   key=(str(Path(f['file'])),l['line_number']);lines[key]=lines.get(key,False) or l['count']>0
scopes={}
for scope in ('lite','shared_simd','combined'):
 vals=[]
 for (name,line),covered in lines.items():
  lite=('/src/lite/' in name or '/include/vsag/lite/' in name) and not name.endswith('_test.cpp')
  simd='/src/simd/' in name and not name.endswith('_test.cpp')
  if (scope=='lite' and lite) or (scope=='shared_simd' and simd) or (scope=='combined' and (lite or simd)):vals.append(covered)
 scopes[scope]={'covered':sum(vals),'total':len(vals),'percent':sum(vals)*100/len(vals)}
 assert scopes[scope]['percent']>=90
(out/'coverage.json').write_text(json.dumps({'fresh_counters':True,'scopes':scopes,'scope_note':'Scoped Lite production/public headers and instantiated shared SIMD,not whole Full'},indent=2)+'\n')
with tarfile.open(out/'coverage-raw.tar.gz','w:gz') as tar:
 for p in gz:tar.add(p,arcname=p.name)
validation={'production_change':True,'public_default_changed':False,'source_head':identity['base_head'],
 'source_sha256':identity['source_sha256'],'tests':{'release':6,'asan_ubsan':5,'fresh_coverage':5,'disabled':4},
 'format_version':15,'tidy_version':15,'limits':['Internal reverse only','Not Full comparison','Not cold I/O','Not100k','Not interleaved queries','Known memory excludes map/allocator/transient','Probe HWM may be inherited'],
 'decision':'Retain incoming32;public reverse remains disabled'}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
with tarfile.open(out/'raw.tar.gz') as tar:raw={m.name.removeprefix('./'):tar.extractfile(m).read() for m in tar if m.isfile()}
for p in logs.glob('*.log'):raw[p.name]=p.read_bytes()
for name in ('src/lite/rabitq_graph_state.h','src/lite/rabitq_snapshot.h','src/lite/rabitq_backend.cpp','src/lite/rabitq_backend_test.cpp','src/lite/graph_allocation_test.cpp','src/basic_types.h','src/simd/kernels/rabitq_compute.h'):
 raw['source-'+Path(name).name]=(root/name).read_bytes()
for name in ('verify.py','validation-script.sh','validation.json','validation-commands.json','coverage.json','collect-run.sh'):raw[name]=(out/name).read_bytes()
raw['candidate.patch']=subprocess.check_output(['git','diff','--','src/lite/rabitq_graph_state.h','src/lite/rabitq_backend_test.cpp'])
with tarfile.open(out/'raw.tar.gz','w:gz') as tar:
 for name,blob in sorted(raw.items()):
  m=tarfile.TarInfo('./'+name);m.size=len(blob);tar.addfile(m,io.BytesIO(blob))
(out/'members.json').write_text(json.dumps({n:sha(b) for n,b in sorted(raw.items())},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('audit',out/'verify.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
result=mod.derive(out);(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
def med(label,v,key):return statistics.median([s['same_snapshot_load_probes'][v][key] for s in result['summary'] if s['dataset']==label])
lines=['# Narrow internal RaBitQ incoming slots (2026-10-11)','',
 'Source evidence:native src/basic_types.h uses uint32_t InnerIdType. Lite incoming source slots',
 'previously used uint64_t. Only incoming rows and transaction backups become uint32_t;',
 'external IDs,outgoing slots,degree counts,models,scoring,budgets,API,snapshot remain unchanged.',
 'Explicit checked conversion rejects slots above UINT32_MAX before insertion. Boundary regression',
 'tests max and max+1;it does not allocate billions of nodes. Disabled reverse has no new slot limit.',
 'Accounting reports4-byte incoming payload and unchanged vector headers. No pool/CSR claim.',
 'Both measured overlays enable reverse via identical one-token false-to-true default transform.',
 'Control is5d633c9 with64-bit incoming;candidate is current32-bit incoming. Both NONE protection.',
 'Public reverse remains false. Journals and failure guarantees remain;logical state,not capacities.','',
 '## Paired measurements','',
 '10k GIST960/Cohere768,600 queries,k10,degree16/maintenance128/query512,CPU0/thread1,three full-ID',
 'passes of true whole-vector Update/Remove/Add,three alternating pairs per dataset,12 builders.',
 '1080000 timed operations. Queries before/after,not interleaved. All paired ordered IDs,hex',
 'distances,hits and snapshot SHA are identical;native Save/Load exact for every builder.','',
 '| Dataset |64/32-bit mixed CRUD ms|Change|Final recall|','|---|---:|---:|---:|']
for label,c in result['comparison'].items():
 lines.append('|%s|%.3f / %.3f|%+.2f%%|%.6f|'%(label,c['crud_ms']['control'],c['crud_ms']['candidate'],c['crud_change_percent'],c['final_recall']['candidate']))
lines+=['','|Dataset/operation|64-bit P50/P99 us|32-bit P50/P99 us|','|---|---:|---:|']
for label,c in result['comparison'].items():
 for name,p in c['operations'].items():
  lines.append('|%s/%s|%.3f / %.3f|%.3f / %.3f|'%(label,name,p['control']['p50_us'],p['control']['p99_us'],p['candidate']['p50_us'],p['candidate']['p99_us']))
lines+=['','## Same-snapshot fresh-process warm loads','',
 'Both loaders consume each identical snapshot three times,72 loads. 160000 incoming edges:',
 'payload1280000 to640000B (-50%);vector headers240000B unchanged,total1520000 to880000B (-42.11%).',
 'Known capacity excludes map nodes/allocator/transient allocations. Resident increment uses',
 '/proc/self/statm after load minus fresh-process baseline. ru_maxrss can inherit launcher HWM,',
 'and builder peak includes matrices and two live indexes;neither proves mutation-only peak.',
 'RAM/page-cache warm measurements are not cold I/O. Snapshot bytes remain unchanged.','',
 '|Dataset|Known capacity64/32 B|Resident increment64/32 KiB|Warm internal load64/32 ms|',
 '|---|---:|---:|---:|']
for label in result['comparison']:
 lines.append('|%s|%.0f / %.0f|%.0f / %.0f|%.3f / %.3f|'%(label,med(label,'control','known_capacity_bytes'),med(label,'candidate','known_capacity_bytes'),med(label,'control','increment_rss_kib'),med(label,'candidate','increment_rss_kib'),med(label,'control','load_ms'),med(label,'candidate','load_ms')))
lines+=['','Quality unchanged,still below research floors. Do not equate this internal-memory gain',
 'with public-default or Full advantage. No SIMD/scoring/query improvement is claimed.','',
 '## Verification','',
 'Release6,ASan/UBSan5,fresh coverage5,RaBitQ-disabled4,format/tidy15 pass. Existing reverse',
 'Update/Add/Remove allocation faults,NONE/RECOUNT/CACHED cold/warm,middle/last/single-node',
 'delete,retry/continued mutation and mixed/growth golden tests remain passing.',
 'Scoped Lite coverage%d/%d=%.2f%%;not whole Full coverage.'%(scopes['lite']['covered'],scopes['lite']['total'],scopes['lite']['percent']),
 'python3 lite/benchmark/results/rabitq-incoming32-20261011/verify.py independently derives',
 '1.08M schedules/quantiles,14400 truth states,72 load byte deltas,exact paired results,',
 'fresh coverage union,header/dependency/source receipts and hashes. Raw actual runner,headers,',
 'adapter commands,query/truth/latencies,probe data,patch,native slot source and logs preserved.',
 'Final replay pins captured candidate header;syntax-checked only,not rerun.',
 'Only19 verified generated counters and new RAM snapshots(after native load/SHA) unlinked;',
 'no old source,data,raw results or shared binaries deleted.PR2904/2926 untouched.','',
 'Next:incoming allocation/layout overhead and fixed-budget quality. Public reverse stays off;',
 '100k/interleaved real CRUD,fresh aligned Full,cold I/O/complete package acceptance remain open.','']
edit(out/'README.md','\n'.join(lines))
p=out/'run-host.py';old=p.read_text()
new=old.replace('    shutil.copyfile(repo / source_names[0], raw / "candidate-state.h")',
'''    with tarfile.open(repo / "lite/benchmark/results/rabitq-incoming32-20261011/raw.tar.gz") as archive:
        (raw / "candidate-state.h").write_bytes(archive.extractfile("./candidate-state.h").read())
    identity["source_sha256"][source_names[0]] = digest(raw / "candidate-state.h")
    assert identity["source_sha256"][source_names[3]] == "TOOL_SHA"
    assert identity["source_sha256"][source_names[4]] == "PREP_SHA"''')
new=new.replace('TOOL_SHA',identity['source_sha256']['lite/benchmark/graph_crud_quality.cpp']).replace('PREP_SHA',identity['source_sha256']['lite/benchmark/prepare_persistent_crud.py']).rstrip()+'\n'
assert new!=old;edit(p,new);compile(new,str(p),'exec')
names=['README.md','run-host.py','verify.py','memory-probe.cpp','raw.tar.gz','members.json','identity.json','rows.json','summary.json','validation.json','validation-commands.json','coverage.json','coverage-raw.tar.gz']
(out/'SHA256SUMS').write_text(''.join(sha((out/n).read_bytes())+'  '+n+'\n' for n in names))
subprocess.run(['python3',str(out/'verify.py')],check=True)
print(json.dumps({'comparison':result['comparison'],'coverage':scopes,'load_medians':{l:{v:{k:med(l,v,k) for k in ('known_capacity_bytes','incoming_capacity_bytes','increment_rss_kib','load_ms')} for v in ('control','candidate')} for l in result['comparison']},'raw_members':len(raw),'raw_bytes':sum(map(len,raw.values()))},indent=2))
PY
