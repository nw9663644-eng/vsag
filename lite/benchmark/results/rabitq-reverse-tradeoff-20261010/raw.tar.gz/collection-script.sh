set -eu
cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import csv,difflib,hashlib,importlib.util,io,json,statistics,subprocess,tarfile
from pathlib import Path
root=Path.cwd();out=root/'lite/benchmark/results/rabitq-reverse-tradeoff-20261010'
logs=Path('/home/ubuntu/project/vsag-lite-reverse-tradeoff-20261010')
sha=lambda b:hashlib.sha256(b).hexdigest()
def edit(path,text):
 old=path.read_text() if path.exists() else ''
 if old==text:return
 name=str(path.relative_to(root))
 subprocess.run(['git','apply','-'],input=''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/'+name if path.exists() else '/dev/null',tofile='b/'+name)),text=True,check=True)
records=json.loads((out/'rows.json').read_text());assert len(records)==12
identity=json.loads((out/'identity.json').read_text())
assert identity['base_head']=='06ab591824bf42ebf43f53770a28860f29405382'
assert all(sha((root/name).read_bytes())==value for name,value in identity['source_sha256'].items())
assert sha((root/'build-lite-fp16-simd-release/libvsag-lite.so').read_bytes())==identity['default_library_sha256']
assert identity['variants']['control']['adapter']==(root/'src/lite/rabitq_backend.cpp').read_text()
with tarfile.open(out/'raw.tar.gz') as archive:
 raw={m.name.removeprefix('./'):archive.extractfile(m).read() for m in archive if m.isfile()}
assert raw['candidate-state.h']==(root/'src/lite/rabitq_graph_state.h').read_bytes()
validation={'production_change':False,'public_default_changed':False,'source_head':identity['base_head'],
 'source_sha256':identity['source_sha256'],'release_tests_this_round':6,'new_harness_format_tidy_version':15,
 'inherited_validation':{'commit':'06ab591','release':6,'asan_ubsan':5,'coverage':5,'disabled':4,
                        'scoped_lite_covered':2924,'scoped_lite_total':3065},
 'not_repeated':['ASan/UBSan production suite','fresh production coverage','disabled production suite'],
 'limits':['not Full comparison','not cold I/O','not100k','not interleaved queries',
           'whole builder peak includes inputs and simultaneous native load',
           'load probe peak may include launcher inherited high-water mark',
           'known memory excludes hash-map allocation and allocator overhead'],
 'decision':'Keep public reverse disabled pending memory/layout and quality work'}
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
for p in logs.glob('*.log'):raw[p.name]=p.read_bytes()
for name in ('src/lite/rabitq_graph_state.h','src/lite/rabitq_snapshot.h','src/lite/rabitq_backend.cpp',
             'src/lite/rabitq_filter_ip.cpp','src/lite/rabitq_filter_ip_avx2.cpp',
             'src/lite/rabitq_filter_ip_avx512.cpp','src/simd/kernels/rabitq_compute.h'):
 raw['source-'+Path(name).name]=(root/name).read_bytes()
raw['verify.py']=(out/'verify.py').read_bytes()
raw['collection-script.sh']=(out/'collect-run.sh').read_bytes()
raw['validation-script.sh']=(out/'validation-script.sh').read_bytes()
raw['validation.json']=(out/'validation.json').read_bytes()
raw['validation-commands.json']=(out/'validation-commands.json').read_bytes()
# Freeze object receipts; identical non-adapter objects are linked into both variants.
objects={}
for value in identity['variants']['control']['link']:
 if value.endswith('.o') and 'adapter.o' not in value:
  p=root/'build-lite-fp16-simd-release'/value
  objects[value]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
raw['shared-objects.json']=(json.dumps(objects,indent=2)+'\n').encode()
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for name,blob in sorted(raw.items()):
  m=tarfile.TarInfo('./'+name);m.size=len(blob);archive.addfile(m,io.BytesIO(blob))
(out/'members.json').write_text(json.dumps({n:sha(b) for n,b in sorted(raw.items())},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('audit',out/'verify.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.derive(out)
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
comparison=result['comparison']
def med(label,variant,key):
 return statistics.median([s['same_snapshot_load_probes'][variant][key] for s in result['summary'] if s['dataset']==label])
lines=['# Current RaBitQ reverse adjacency tradeoff (2026-10-10)','',
 'No production C++ change in this experiment. Both adapters are byte-identical to current',
 'public RaBitQBackend and use the same06ab591 state header. Control keeps reverse=false;',
 'candidate changes only that constructor default to true. Protection stays NONE.',
 'Previous Update/Add/Remove journals exist in both variants. Public default remains false.',
 'This is NOT the preceding old-copy versus local-Remove comparison.','',
 '## Fixed-budget mixed CRUD','',
 '10k GIST960/Cohere768,600 preserved queries,k10,degree16,maintenance128,query512,CPU0,one thread.',
 'Three full-ID passes of true whole-vector Update/Remove/Add per builder,90000 operations.',
 'Three alternating pairs per dataset,12 fresh builders;1080000 measured operations.',
 'Initial/final queries are outside mutation loops; this is not interleaved-query acceptance.',
 'Native public Save/Load verifies exact IDs/distances for every builder.','',
 '| Dataset | Reverse off/on CRUD ms | Change | Final recall off/on | Builder peak KiB off/on |',
 '|---|---:|---:|---:|---:|']
for label,c in comparison.items():
 lines.append('| %s | %.3f / %.3f | %+.2f%% | %.6f / %.6f | %.0f / %.0f |'%(
  label,c['crud_ms']['control'],c['crud_ms']['candidate'],c['crud_change_percent'],
  c['final_recall']['control'],c['final_recall']['candidate'],
  c['external_peak_rss_kib']['control'],c['external_peak_rss_kib']['candidate']))
lines+=['','| Dataset/operation | Off P50/P99 us | On P50/P99 us |','|---|---:|---:|']
for label,c in comparison.items():
 for name,v in c['operations'].items():
  lines.append('| %s/%s | %.3f / %.3f | %.3f / %.3f |'%(
    label,name,v['control']['p50_us'],v['control']['p99_us'],v['candidate']['p50_us'],v['candidate']['p99_us']))
lines+=['','## Same-snapshot load and resident memory','',
 'Each builder snapshot is loaded by BOTH flags,three fresh processes per flag (72 loads).',
 'This isolates flag cost from graph topology. Snapshot inputs are RAM/page-cache warm.',
 'For each snapshot the two loaders have identical model/codes/IDs/outgoing edges/map entries;',
 'known-byte difference equals incoming logical/capacity bytes exactly.',
 'Known bytes include vector headers/payload/capacity,not hash-map node/allocator/transient bytes.',
 'Resident increment is post-load /proc/self/statm minus that fresh process baseline.',
 'ru_maxrss is retained raw but can include launcher inherited HWM; it is not loader-only peak.',
 'Whole builder peak also includes base/replacements/build/query and two live indexes on load.',
 'Consequently its small deltas cannot establish mutation-only memory superiority.','',
 '| Dataset | Known capacity off/on B | Incoming B | Resident increment off/on KiB | Warm internal load off/on ms |',
 '|---|---:|---:|---:|---:|']
for label in comparison:
 lines.append('| %s | %.0f / %.0f | %.0f | %.0f / %.0f | %.3f / %.3f |'%(
  label,med(label,'control','known_capacity_bytes'),med(label,'candidate','known_capacity_bytes'),
  med(label,'candidate','incoming_capacity_bytes'),med(label,'control','increment_rss_kib'),
  med(label,'candidate','increment_rss_kib'),med(label,'control','load_ms'),med(label,'candidate','load_ms')))
lines+=['','All measured incoming edges equal outgoing edges; exact initial/final result comparisons',
 'and per-query recall deltas are in summary.json. No assumed equality or quality improvement.',
 'Fixed-budget recall still fails research floors; no public-default adoption is justified solely',
 'by this speedup. Binary/snapshot format is unchanged; overlay ELF sizes are not package sizing.',
 'Remaining100k,long interleaved CRUD,fresh aligned Full,cold I/O and complete package remain open.','',
 '## Evidence and replay','',
 'python3 lite/benchmark/results/rabitq-reverse-tradeoff-20261010/verify.py',
 'independently checks1.08M operation schedule/quantiles,14400 truth intersections,72 load probes,',
 'same-snapshot logical/capacity deltas,paired recall/results,header/dependency binding and hashes.',
 'Release6 repeated this round;new probe format15/tidy15 and Python syntax checks pass.',
 'Production source unchanged: sanitizer/coverage/OFF results are inherited from06ab591,not rerun.',
 'Setup mode spelling corrected before timing;interrupted setup log retained.',
 'After timing,RAM probe executables were rebuilt from captured headers for malformed-input',
 'checks only;initial executable-presence assertion stopped before those checks,no timing rerun.',
 'Only newly generated RAM snapshots were unlinked after exact native load and SHA receipts.',
 'No old source,data,raw results or shared artifacts were deleted;PR2904/2926 untouched.','',
 'run-host.py pins measured header from raw.tar.gz for replay;retained data/object dependencies',
 'and matching SIMD are required. Final replay is syntax-checked,not rerun.','',
 'Decision: retain public reverse=false;next investigate incoming layout/allocator footprint',
 'without losing local mutation/exception guarantees,then fixed-budget graph quality.','']
edit(out/'README.md','\n'.join(lines))
# Pin measured state, not a future checkout. Archive still contains the actual timing runner.
p=out/'run-host.py';old=p.read_text()
new=old.replace('    shutil.copyfile(repo / source_names[0], raw / "candidate-state.h")',
'''    with tarfile.open(repo / "lite/benchmark/results/rabitq-reverse-tradeoff-20261010/raw.tar.gz") as archive:
        (raw / "candidate-state.h").write_bytes(archive.extractfile("./candidate-state.h").read())
    identity["source_sha256"][source_names[0]] = digest(raw / "candidate-state.h")
    assert identity["source_sha256"][source_names[3]] == "TOOL_SHA"
    assert identity["source_sha256"][source_names[4]] == "PREP_SHA"''')
new=new.replace('TOOL_SHA',identity['source_sha256']['lite/benchmark/graph_crud_quality.cpp']).replace('PREP_SHA',identity['source_sha256']['lite/benchmark/prepare_persistent_crud.py'])
assert 'archive.extractfile' in new;edit(p,new);compile(new,str(p),'exec')
names=['README.md','run-host.py','verify.py','memory-probe.cpp','raw.tar.gz','members.json','identity.json','rows.json','summary.json','validation.json','validation-commands.json']
(out/'SHA256SUMS').write_text(''.join(sha((out/n).read_bytes())+'  '+n+'\n' for n in names))
subprocess.run(['python3',str(out/'verify.py')],check=True)
print(json.dumps({'comparison':comparison,'load_probe_medians':{label:{v:{k:med(label,v,k) for k in ('known_capacity_bytes','incoming_capacity_bytes','increment_rss_kib','load_ms')} for v in ('control','candidate')} for label in comparison},'raw_members':len(raw),'raw_bytes':sum(map(len,raw.values()))},indent=2))
PY
