cd /home/ubuntu/project/vsag-lite-baseline-v01
python3 - <<'PY'
import json,subprocess,tempfile
from pathlib import Path
out=Path('lite/benchmark/results/rabitq-reverse-tradeoff-20261010');logs=Path('/home/ubuntu/project/vsag-lite-reverse-tradeoff-20261010')
records=[]
def run(tag,command,expected=0):
 with (logs/(tag+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=log)
 records.append({'tag':tag,'command':command,'exit':result.returncode,'expected_exit':expected})
 (out/'validation-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 assert result.returncode==expected,tag
run('release-test',['ctest','--test-dir','build-lite-fp16-simd-release','-V'])
run('format-probe',['clang-format-15','--dry-run','--Werror',str(out/'memory-probe.cpp')])
run('tidy-probe',['clang-tidy-15','-warnings-as-errors=*',str(out/'memory-probe.cpp'),'--','-std=c++17','-I'+str(Path.cwd()/'src'),'-I'+str(Path.cwd()/'include')])
run('python-syntax',['python3','-c',"from pathlib import Path; [compile(p.read_text(),str(p),'exec') for p in (Path('"+str(out/'run-host.py')+"'),Path('"+str(out/'verify.py')+"'))]"])
identity=json.loads((out/'identity.json').read_text())
with tempfile.NamedTemporaryFile(prefix='vsag-reverse-tradeoff-invalid-',dir='/dev/shm',delete=False) as f:
 f.write(b'invalid');bad=Path(f.name)
try:
 for v in ('control','candidate'):
  exe=Path(identity['variants'][v]['probe_compile'][-1])
  assert exe.is_file()
  run('invalid-probe-'+v,[str(exe),str(bad)],1)
finally:
 assert bad.resolve().parent==Path('/dev/shm') and bad.name.startswith('vsag-reverse-tradeoff-invalid-')
 bad.unlink()
print('Six validation commands passed')
PY
